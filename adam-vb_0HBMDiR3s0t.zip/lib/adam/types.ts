export type CategoryId =
  | "electronics"
  | "fashion"
  | "home"
  | "groceries"
  | "beauty"
  | "sports"
  | "automotive"
  | "books"
  | "toys"
  | "gaming";

export interface Category {
  id: CategoryId;
  name: string;
  icon: string;
  hue: number;
  subcategories: string[];
}

export interface Seller {
  id: string;
  name: string;
  rating: number;
  reviewCount: number;
  joined: string;
  verified: boolean;
}

export interface Product {
  id: string;
  name: string;
  price: number; // in Pi
  originalPrice?: number;
  image: string;
  images: string[];
  category: CategoryId;
  subcategory: string;
  brand: string;
  rating: number;
  reviewCount: number;
  sellerId: string;
  description: string;
  specs: { label: string; value: string }[];
  stock: number;
  flashDeal?: boolean;
  trending?: boolean;
  featured?: boolean;
}

export interface Review {
  id: string;
  productId: string;
  user: string;
  rating: number;
  comment: string;
  date: string;
  photos?: string[];
}

export interface CartItem {
  productId: string;
  qty: number;
}

export type OrderStatus =
  | "pending"
  | "confirmed"
  | "shipped"
  | "delivered"
  | "returned"
  | "cancelled";

export interface OrderLine {
  productId: string;
  name: string;
  image: string;
  price: number;
  qty: number;
}

export interface Order {
  id: string;
  trackingNumber: string;
  lines: OrderLine[];
  subtotal: number;
  shipping: number;
  tax: number;
  discount: number;
  total: number;
  status: OrderStatus;
  date: number;
  pointsEarned: number;
  paymentId?: string;
  address: string;
}

export interface Address {
  id: string;
  label: string;
  recipient: string;
  line: string;
  city: string;
  phone: string;
}

export interface AdamState {
  cart: CartItem[];
  savedForLater: string[];
  wishlist: string[];
  compare: string[];
  recentlyViewed: string[];
  orders: Order[];
  reviews: Review[];
  loyaltyPoints: number;
  totalSpent: number;
  addresses: Address[];
  notifications: boolean;
}

export const LOYALTY_TIERS = [
  { name: "Bronze", min: 0, hue: 30, perk: "1% back in points" },
  { name: "Silver", min: 200, hue: 0, perk: "2% back + free shipping" },
  { name: "Gold", min: 600, hue: 85, perk: "3% back + priority support" },
  { name: "Platinum", min: 1500, hue: 250, perk: "5% back + early deals" },
] as const;

// points earned per 1 Pi spent
export const POINTS_PER_PI = 10;
// 100 points = 1 Pi discount
export const POINTS_TO_PI = 100;

export function tierFor(totalSpent: number) {
  let current = LOYALTY_TIERS[0];
  for (const t of LOYALTY_TIERS) {
    if (totalSpent >= t.min) current = t;
  }
  const idx = LOYALTY_TIERS.indexOf(current);
  const next = LOYALTY_TIERS[idx + 1];
  return { current, next };
}

export const CHECKOUT_PRODUCT_SLUG = "marketplace_order";

export function uid(prefix = "id"): string {
  return `${prefix}_${Date.now().toString(36)}_${Math.random()
    .toString(36)
    .slice(2, 7)}`;
}

export function fmtPi(n: number): string {
  return `π ${n.toLocaleString(undefined, {
    minimumFractionDigits: n % 1 === 0 ? 0 : 2,
    maximumFractionDigits: 2,
  })}`;
}

export function timeAgo(ts: number): string {
  const diff = Date.now() - ts;
  const m = Math.floor(diff / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  return `${d}d ago`;
}

export function fmtDate(ts: number): string {
  return new Date(ts).toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}
