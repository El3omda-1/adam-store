import type {
  Category,
  Product,
  Review,
  Seller,
  CategoryId,
} from "./types";

export const CATEGORIES: Category[] = [
  {
    id: "electronics",
    name: "Electronics",
    icon: "Smartphone",
    hue: 230,
    subcategories: ["Phones", "Laptops", "Audio", "Cameras", "Accessories"],
  },
  {
    id: "fashion",
    name: "Fashion",
    icon: "Shirt",
    hue: 330,
    subcategories: ["Men", "Women", "Shoes", "Bags", "Watches"],
  },
  {
    id: "home",
    name: "Home",
    icon: "Sofa",
    hue: 160,
    subcategories: ["Furniture", "Kitchen", "Decor", "Lighting", "Bedding"],
  },
  {
    id: "groceries",
    name: "Groceries",
    icon: "ShoppingBasket",
    hue: 130,
    subcategories: ["Snacks", "Beverages", "Pantry", "Fresh", "Organic"],
  },
  {
    id: "beauty",
    name: "Beauty",
    icon: "Sparkles",
    hue: 350,
    subcategories: ["Skincare", "Makeup", "Fragrance", "Hair", "Tools"],
  },
  {
    id: "sports",
    name: "Sports",
    icon: "Dumbbell",
    hue: 200,
    subcategories: ["Fitness", "Outdoor", "Cycling", "Yoga", "Apparel"],
  },
  {
    id: "automotive",
    name: "Auto",
    icon: "Car",
    hue: 25,
    subcategories: ["Accessories", "Care", "Electronics", "Tools", "Parts"],
  },
  {
    id: "books",
    name: "Books",
    icon: "BookOpen",
    hue: 280,
    subcategories: ["Fiction", "Business", "Kids", "Science", "Comics"],
  },
  {
    id: "toys",
    name: "Toys",
    icon: "ToyBrick",
    hue: 50,
    subcategories: ["Educational", "Action", "Puzzles", "Outdoor", "Plush"],
  },
  {
    id: "gaming",
    name: "Gaming",
    icon: "Gamepad2",
    hue: 265,
    subcategories: ["Consoles", "Games", "Accessories", "PC", "VR"],
  },
];

export const SELLERS: Seller[] = [
  { id: "s1", name: "TechNova Store", rating: 4.8, reviewCount: 12480, joined: "2021", verified: true },
  { id: "s2", name: "Urban Threads", rating: 4.6, reviewCount: 8210, joined: "2020", verified: true },
  { id: "s3", name: "HomeLuxe", rating: 4.7, reviewCount: 5630, joined: "2022", verified: true },
  { id: "s4", name: "FreshMart", rating: 4.5, reviewCount: 9940, joined: "2019", verified: true },
  { id: "s5", name: "GlowBeauty", rating: 4.9, reviewCount: 7120, joined: "2021", verified: true },
  { id: "s6", name: "PeakSports", rating: 4.4, reviewCount: 3380, joined: "2023", verified: false },
  { id: "s7", name: "DriveGear", rating: 4.6, reviewCount: 2210, joined: "2022", verified: true },
  { id: "s8", name: "PageTurner Books", rating: 4.8, reviewCount: 4150, joined: "2020", verified: true },
];

function img(seed: string) {
  return `/placeholder.svg?height=400&width=400&query=${encodeURIComponent(seed)}`;
}

interface Seed {
  id: string;
  name: string;
  price: number;
  original?: number;
  category: CategoryId;
  sub: string;
  brand: string;
  rating: number;
  reviews: number;
  seller: string;
  desc: string;
  stock: number;
  specs: [string, string][];
  flash?: boolean;
  trending?: boolean;
  featured?: boolean;
  q: string;
}

const SEEDS: Seed[] = [
  { id: "p1", name: "Aurora Pro Smartphone 5G", price: 42, original: 58, category: "electronics", sub: "Phones", brand: "Aurora", rating: 4.7, reviews: 2103, seller: "s1", stock: 34, desc: "Flagship 6.7-inch AMOLED display, triple 108MP camera, 120Hz refresh and all-day battery.", specs: [["Display", "6.7\" AMOLED 120Hz"], ["Camera", "108MP triple"], ["Battery", "5000 mAh"], ["Storage", "256GB"]], flash: true, trending: true, featured: true, q: "modern smartphone product" },
  { id: "p2", name: "SkyBuds Wireless Earbuds", price: 9.5, original: 15, category: "electronics", sub: "Audio", brand: "SkyBuds", rating: 4.5, reviews: 5820, seller: "s1", stock: 120, desc: "Active noise cancelling earbuds with 32h battery and crystal-clear calls.", specs: [["ANC", "Yes"], ["Battery", "32h total"], ["Bluetooth", "5.3"]], flash: true, trending: true, q: "wireless earbuds white" },
  { id: "p3", name: "ProBook Air Laptop 14\"", price: 78, original: 95, category: "electronics", sub: "Laptops", brand: "ProBook", rating: 4.8, reviews: 940, seller: "s1", stock: 18, desc: "Ultra-thin laptop with 14-inch Retina display, 16GB RAM and a 12-core chip.", specs: [["CPU", "12-core"], ["RAM", "16GB"], ["SSD", "512GB"], ["Weight", "1.2kg"]], featured: true, q: "thin silver laptop" },
  { id: "p4", name: "Vision 4K Action Camera", price: 22, category: "electronics", sub: "Cameras", brand: "Vision", rating: 4.4, reviews: 1280, seller: "s1", stock: 56, desc: "Waterproof 4K60 action camera with stabilization and dual screens.", specs: [["Video", "4K60"], ["Waterproof", "10m"], ["Stabilization", "Yes"]], trending: true, q: "action camera black" },
  { id: "p5", name: "Classic Denim Jacket", price: 12, original: 18, category: "fashion", sub: "Men", brand: "Urban", rating: 4.6, reviews: 3420, seller: "s2", stock: 88, desc: "Timeless denim jacket with a relaxed fit and durable stitching.", specs: [["Material", "100% Cotton"], ["Fit", "Relaxed"]], featured: true, q: "blue denim jacket" },
  { id: "p6", name: "Runner Knit Sneakers", price: 16, original: 24, category: "fashion", sub: "Shoes", brand: "Stride", rating: 4.5, reviews: 6210, seller: "s2", stock: 140, desc: "Breathable knit sneakers with responsive foam cushioning.", specs: [["Upper", "Knit mesh"], ["Sole", "Foam"]], flash: true, trending: true, q: "knit running sneakers" },
  { id: "p7", name: "Leather Crossbody Bag", price: 19, category: "fashion", sub: "Bags", brand: "Lumi", rating: 4.7, reviews: 1830, seller: "s2", stock: 42, desc: "Premium vegan leather crossbody bag with gold hardware.", specs: [["Material", "Vegan leather"], ["Strap", "Adjustable"]], q: "leather crossbody bag tan" },
  { id: "p8", name: "Chrono Steel Watch", price: 34, original: 49, category: "fashion", sub: "Watches", brand: "Chrono", rating: 4.8, reviews: 720, seller: "s2", stock: 25, desc: "Stainless steel automatic watch with sapphire glass.", specs: [["Movement", "Automatic"], ["Glass", "Sapphire"], ["Water", "50m"]], featured: true, q: "steel wrist watch" },
  { id: "p9", name: "Nordic Lounge Chair", price: 64, original: 80, category: "home", sub: "Furniture", brand: "HomeLuxe", rating: 4.6, reviews: 510, seller: "s3", stock: 12, desc: "Mid-century lounge chair with oak legs and soft bouclé fabric.", specs: [["Frame", "Oak"], ["Fabric", "Bouclé"]], featured: true, q: "modern lounge chair" },
  { id: "p10", name: "Ceramic Cookware Set", price: 28, original: 40, category: "home", sub: "Kitchen", brand: "ChefPro", rating: 4.5, reviews: 2240, seller: "s3", stock: 60, desc: "10-piece non-stick ceramic cookware set, dishwasher safe.", specs: [["Pieces", "10"], ["Coating", "Ceramic"]], flash: true, q: "cookware set pots pans" },
  { id: "p11", name: "Aroma LED Floor Lamp", price: 21, category: "home", sub: "Lighting", brand: "Glow", rating: 4.4, reviews: 880, seller: "s3", stock: 75, desc: "Dimmable LED floor lamp with warm and cool tones.", specs: [["Type", "LED"], ["Dimmable", "Yes"]], trending: true, q: "modern floor lamp" },
  { id: "p12", name: "Cloud Comfort Bedding Set", price: 25, original: 33, category: "home", sub: "Bedding", brand: "DreamCo", rating: 4.7, reviews: 1410, seller: "s3", stock: 90, desc: "Ultra-soft microfiber 4-piece bedding set.", specs: [["Pieces", "4"], ["Material", "Microfiber"]], q: "white bedding set" },
  { id: "p13", name: "Organic Trail Mix 1kg", price: 3.5, category: "groceries", sub: "Snacks", brand: "FreshMart", rating: 4.6, reviews: 3120, seller: "s4", stock: 200, desc: "Premium organic trail mix with nuts, seeds and dried fruit.", specs: [["Weight", "1kg"], ["Organic", "Yes"]], trending: true, q: "trail mix nuts bag" },
  { id: "p14", name: "Cold Brew Coffee Pack", price: 5.2, original: 7, category: "groceries", sub: "Beverages", brand: "BrewLab", rating: 4.5, reviews: 990, seller: "s4", stock: 150, desc: "Smooth cold brew concentrate, 6-pack.", specs: [["Pack", "6"], ["Type", "Concentrate"]], flash: true, q: "cold brew coffee bottles" },
  { id: "p15", name: "Himalayan Pink Salt 500g", price: 2.1, category: "groceries", sub: "Pantry", brand: "PureEarth", rating: 4.7, reviews: 640, seller: "s4", stock: 300, desc: "Fine Himalayan pink salt, mineral-rich.", specs: [["Weight", "500g"]], q: "pink salt jar" },
  { id: "p16", name: "Radiance Vitamin C Serum", price: 11, original: 16, category: "beauty", sub: "Skincare", brand: "GlowBeauty", rating: 4.9, reviews: 8430, seller: "s5", stock: 110, desc: "Brightening vitamin C serum with hyaluronic acid.", specs: [["Volume", "30ml"], ["Key", "Vitamin C"]], flash: true, trending: true, featured: true, q: "skincare serum bottle" },
  { id: "p17", name: "Velvet Matte Lipstick Set", price: 8.5, category: "beauty", sub: "Makeup", brand: "GlowBeauty", rating: 4.6, reviews: 2890, seller: "s5", stock: 95, desc: "Long-lasting matte lipstick set of 5 shades.", specs: [["Shades", "5"], ["Finish", "Matte"]], trending: true, q: "lipstick set makeup" },
  { id: "p18", name: "Midnight Eau de Parfum", price: 27, original: 38, category: "beauty", sub: "Fragrance", brand: "Aura", rating: 4.7, reviews: 1120, seller: "s5", stock: 48, desc: "Warm woody fragrance with amber and vanilla notes.", specs: [["Volume", "100ml"], ["Notes", "Amber, Vanilla"]], featured: true, q: "perfume bottle dark" },
  { id: "p19", name: "Adjustable Dumbbell 20kg", price: 36, original: 45, category: "sports", sub: "Fitness", brand: "PeakSports", rating: 4.5, reviews: 760, seller: "s6", stock: 30, desc: "Space-saving adjustable dumbbell, 2-20kg per hand.", specs: [["Max", "20kg"], ["Adjustable", "Yes"]], trending: true, q: "adjustable dumbbell" },
  { id: "p20", name: "Pro Yoga Mat", price: 7.5, category: "sports", sub: "Yoga", brand: "ZenFit", rating: 4.6, reviews: 4100, seller: "s6", stock: 180, desc: "Non-slip eco yoga mat with alignment lines.", specs: [["Thickness", "6mm"], ["Material", "TPE"]], q: "yoga mat rolled" },
  { id: "p21", name: "TrailBlaze Mountain Bike", price: 120, original: 150, category: "sports", sub: "Cycling", brand: "PeakSports", rating: 4.7, reviews: 320, seller: "s6", stock: 8, desc: "21-speed mountain bike with hydraulic disc brakes.", specs: [["Gears", "21"], ["Brakes", "Hydraulic"]], featured: true, q: "mountain bike" },
  { id: "p22", name: "Car Dash Cam 1080p", price: 14, original: 20, category: "automotive", sub: "Electronics", brand: "DriveGear", rating: 4.4, reviews: 1560, seller: "s7", stock: 64, desc: "Full HD dash cam with night vision and loop recording.", specs: [["Video", "1080p"], ["Night", "Yes"]], flash: true, q: "car dash cam" },
  { id: "p23", name: "Premium Car Care Kit", price: 9, category: "automotive", sub: "Care", brand: "DriveGear", rating: 4.5, reviews: 870, seller: "s7", stock: 100, desc: "Complete wash and wax kit with microfiber towels.", specs: [["Pieces", "8"]], q: "car cleaning kit" },
  { id: "p24", name: "Wireless Car Charger Mount", price: 6.5, category: "automotive", sub: "Accessories", brand: "DriveGear", rating: 4.3, reviews: 2010, seller: "s7", stock: 130, desc: "Auto-clamp 15W wireless charging phone mount.", specs: [["Power", "15W"], ["Auto-clamp", "Yes"]], trending: true, q: "car phone charger mount" },
  { id: "p25", name: "The Quiet Mind (Hardcover)", price: 4.5, original: 6, category: "books", sub: "Business", brand: "PageTurner", rating: 4.8, reviews: 3300, seller: "s8", stock: 220, desc: "Bestselling guide to focus and deep work.", specs: [["Pages", "320"], ["Format", "Hardcover"]], trending: true, q: "hardcover book cover" },
  { id: "p26", name: "Galaxy Atlas Kids Book", price: 3.2, category: "books", sub: "Kids", brand: "PageTurner", rating: 4.7, reviews: 1240, seller: "s8", stock: 150, desc: "Illustrated atlas of the solar system for curious kids.", specs: [["Pages", "96"], ["Age", "6-12"]], q: "kids space book" },
  { id: "p27", name: "Build Master 1200pc Bricks", price: 18, original: 26, category: "toys", sub: "Educational", brand: "BrickWorld", rating: 4.6, reviews: 2670, seller: "s8", stock: 70, desc: "1200-piece creative building brick set with storage box.", specs: [["Pieces", "1200"], ["Age", "5+"]], flash: true, featured: true, q: "building bricks toy" },
  { id: "p28", name: "Plush Cloud Bear", price: 5.5, category: "toys", sub: "Plush", brand: "Cuddle", rating: 4.9, reviews: 1890, seller: "s8", stock: 160, desc: "Super-soft 40cm plush teddy bear.", specs: [["Size", "40cm"]], trending: true, q: "plush teddy bear" },
  { id: "p29", name: "Nexus Game Console", price: 145, original: 180, category: "gaming", sub: "Consoles", brand: "Nexus", rating: 4.8, reviews: 1450, seller: "s1", stock: 14, desc: "Next-gen 4K gaming console with 1TB SSD and ultra-fast load times.", specs: [["Storage", "1TB SSD"], ["Output", "4K 120fps"]], featured: true, trending: true, q: "game console black" },
  { id: "p30", name: "Pro Wireless Controller", price: 13, original: 19, category: "gaming", sub: "Accessories", brand: "Nexus", rating: 4.6, reviews: 3920, seller: "s1", stock: 85, desc: "Low-latency wireless controller with textured grips.", specs: [["Connection", "Wireless"], ["Battery", "40h"]], flash: true, q: "game controller" },
  { id: "p31", name: "Mech RGB Keyboard", price: 17, original: 25, category: "gaming", sub: "PC", brand: "KeyForge", rating: 4.7, reviews: 2100, seller: "s1", stock: 58, desc: "Hot-swap mechanical keyboard with per-key RGB.", specs: [["Switches", "Hot-swap"], ["RGB", "Per-key"]], trending: true, q: "rgb mechanical keyboard" },
  { id: "p32", name: "Immersive VR Headset", price: 88, original: 110, category: "gaming", sub: "VR", brand: "Nexus", rating: 4.5, reviews: 640, seller: "s1", stock: 20, desc: "Standalone VR headset with 4K per eye and hand tracking.", specs: [["Display", "4K/eye"], ["Tracking", "Hand"]], featured: true, q: "vr headset white" },
];

export function buildProducts(): Product[] {
  return SEEDS.map((s) => ({
    id: s.id,
    name: s.name,
    price: s.price,
    originalPrice: s.original,
    image: img(s.q),
    images: [img(s.q), img(s.q + " angle"), img(s.q + " detail")],
    category: s.category,
    subcategory: s.sub,
    brand: s.brand,
    rating: s.rating,
    reviewCount: s.reviews,
    sellerId: s.seller,
    description: s.desc,
    specs: s.specs.map(([label, value]) => ({ label, value })),
    stock: s.stock,
    flashDeal: s.flash,
    trending: s.trending,
    featured: s.featured,
  }));
}

export const PRODUCTS = buildProducts();

export function getProduct(id: string): Product | undefined {
  return PRODUCTS.find((p) => p.id === id);
}

export function getSeller(id: string): Seller | undefined {
  return SELLERS.find((s) => s.id === id);
}

export const SEED_REVIEWS: Review[] = [
  { id: "r1", productId: "p1", user: "Mia R.", rating: 5, comment: "Camera quality is unreal for the price. Super fast shipping!", date: "2 days ago" },
  { id: "r2", productId: "p1", user: "Jonas K.", rating: 4, comment: "Great phone, battery lasts all day. Screen is gorgeous.", date: "1 week ago" },
  { id: "r3", productId: "p2", user: "Lena P.", rating: 5, comment: "Noise cancelling actually works. Love them.", date: "3 days ago" },
  { id: "r4", productId: "p6", user: "Carlos M.", rating: 5, comment: "Most comfortable sneakers I've owned. True to size.", date: "5 days ago" },
  { id: "r5", productId: "p16", user: "Aisha T.", rating: 5, comment: "My skin is glowing after 2 weeks. Holy grail serum!", date: "1 day ago" },
  { id: "r6", productId: "p16", user: "Noor S.", rating: 5, comment: "Lightweight and absorbs fast. Will repurchase.", date: "4 days ago" },
  { id: "r7", productId: "p29", user: "Dani V.", rating: 5, comment: "Load times are instant. Best console upgrade ever.", date: "1 week ago" },
  { id: "r8", productId: "p9", user: "Emma L.", rating: 4, comment: "Beautiful chair, very comfy. Assembly was easy.", date: "6 days ago" },
];

export const TRENDING_SEARCHES = [
  "wireless earbuds",
  "smartphone",
  "sneakers",
  "vitamin c serum",
  "game console",
  "yoga mat",
  "coffee",
  "denim jacket",
];
