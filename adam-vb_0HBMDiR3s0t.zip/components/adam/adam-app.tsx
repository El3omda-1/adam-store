'use client';

import { AdamProvider, useAdam } from '@/contexts/adam-context';
import { HomeView } from './views/home-view';
import { CategoriesView } from './views/categories-view';
import { CategoryView } from './views/category-view';
import { SearchView } from './views/search-view';
import { ProductDetailView } from './views/product-detail-view';
import { CartView } from './views/cart-view';
import { CheckoutView } from './views/checkout-view';
import { WishlistView } from './views/wishlist-view';
import { OrdersView } from './views/orders-view';
import { OrderDetailView } from './views/order-detail-view';
import { AccountView } from './views/account-view';
import { ProfileView } from './views/profile-view';
import { CompareView } from './views/compare-view';
import { SettingsView } from './views/settings-view';
import { AddressesView } from './views/addresses-view';
import { Header } from './header';
import { BottomNav } from './bottom-nav';
import { ToastHost } from './toast-host';
import { Spinner } from './ui-bits';

function AdamShell() {
  const { ready, state, tab } = useAdam();

  if (!ready) {
    return (
      <div className="flex items-center justify-center h-screen w-full bg-background">
        <Spinner />
      </div>
    );
  }

  const isTabScreen = ['home', 'categories', 'cart', 'wishlist', 'account'].includes(tab);

  return (
    <div className="fixed inset-0 flex flex-col h-screen w-screen max-w-md mx-auto bg-background overflow-hidden">
      {/* Header */}
      {isTabScreen && <Header />}

      {/* Main Content */}
      <main className="flex-1 overflow-hidden flex flex-col">
        {tab === 'home' && <HomeView />}
        {tab === 'categories' && <CategoriesView />}
        {tab === 'category' && <CategoryView />}
        {tab === 'search' && <SearchView />}
        {tab === 'product' && <ProductDetailView />}
        {tab === 'cart' && <CartView />}
        {tab === 'checkout' && <CheckoutView />}
        {tab === 'wishlist' && <WishlistView />}
        {tab === 'orders' && <OrdersView />}
        {tab === 'order-detail' && <OrderDetailView />}
        {tab === 'account' && <AccountView />}
        {tab === 'profile' && <ProfileView />}
        {tab === 'compare' && <CompareView />}
        {tab === 'settings' && <SettingsView />}
        {tab === 'addresses' && <AddressesView />}
      </main>

      {/* Bottom Navigation */}
      {isTabScreen && <BottomNav />}

      {/* Toast Container */}
      <ToastHost />
    </div>
  );
}

export function AdamMarketplace() {
  return (
    <AdamProvider>
      <AdamShell />
    </AdamProvider>
  );
}
