"use client";

import { useTheme } from "next-themes";
import { useEffect, useState } from "react";
import { useAdam } from "@/contexts/adam-context";
import { Icon } from "./ui-bits";

const TAB_TITLES: Record<string, string> = {
  home: "",
  categories: "Categories",
  cart: "Your Cart",
  wishlist: "Wishlist",
  account: "Account",
};

const SCREEN_TITLES: Record<string, string> = {
  product: "Product",
  category: "",
  search: "Search",
  checkout: "Checkout",
  orders: "My Orders",
  "order-detail": "Order Details",
  profile: "Loyalty & Profile",
  compare: "Compare",
  seller: "Seller",
  deals: "Flash Deals",
  addresses: "Addresses",
  settings: "Settings",
};

function ThemeToggle() {
  const { theme, setTheme, resolvedTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  const current = mounted ? resolvedTheme : "light";
  return (
    <button
      aria-label="Toggle theme"
      onClick={() => setTheme(current === "dark" ? "light" : "dark")}
      className="grid h-10 w-10 place-items-center rounded-full bg-secondary text-foreground active-press"
    >
      <Icon name={current === "dark" ? "Sun" : "Moon"} className="h-5 w-5" />
    </button>
  );
}

export function Header() {
  const { screen, tab, navigate, back, cartCount, setTab } = useAdam();

  const isTab = screen.name === "tab";

  // Home tab: branded header with search
  if (isTab && tab === "home") {
    return (
      <header className="shrink-0 bg-primary text-primary-foreground px-4 pt-3 pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="grid h-9 w-9 place-items-center rounded-xl bg-primary-foreground/15">
              <Icon name="ShoppingBag" className="h-5 w-5" />
            </div>
            <div className="leading-tight">
              <div className="text-lg font-extrabold tracking-tight">Adam</div>
              <div className="text-[10px] opacity-80">Shop everything · pay with Pi</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              aria-label="Cart"
              onClick={() => setTab("cart")}
              className="relative grid h-10 w-10 place-items-center rounded-full bg-primary-foreground/15 active-press"
            >
              <Icon name="ShoppingCart" className="h-5 w-5" />
              {cartCount > 0 && (
                <span className="absolute -right-1 -top-1 grid h-4 min-w-4 place-items-center rounded-full bg-accent px-1 text-[10px] font-bold text-accent-foreground">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>
        <button
          onClick={() => navigate("search")}
          className="mt-3 flex w-full items-center gap-2 rounded-full bg-primary-foreground px-4 py-2.5 text-left active-press"
        >
          <Icon name="Search" className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm text-muted-foreground">
            Search products, brands and more…
          </span>
        </button>
      </header>
    );
  }

  const title = isTab ? TAB_TITLES[tab] : SCREEN_TITLES[screen.name] ?? "";

  return (
    <header className="shrink-0 sticky top-0 z-30 flex items-center gap-2 border-b border-border bg-card/95 px-3 py-2.5 backdrop-blur">
      {!isTab ? (
        <button
          aria-label="Back"
          onClick={back}
          className="grid h-10 w-10 place-items-center rounded-full bg-secondary text-foreground active-press"
        >
          <Icon name="ChevronLeft" className="h-5 w-5" />
        </button>
      ) : (
        <div className="w-1" />
      )}
      <h1 className="flex-1 truncate text-base font-bold text-foreground">
        {title}
      </h1>
      {isTab && tab !== "cart" && (
        <button
          aria-label="Search"
          onClick={() => navigate("search")}
          className="grid h-10 w-10 place-items-center rounded-full bg-secondary text-foreground active-press"
        >
          <Icon name="Search" className="h-5 w-5" />
        </button>
      )}
      {(isTab && tab === "account") && <ThemeToggle />}
      {!isTab && screen.name === "product" && (
        <button
          aria-label="Cart"
          onClick={() => setTab("cart")}
          className="relative grid h-10 w-10 place-items-center rounded-full bg-secondary text-foreground active-press"
        >
          <Icon name="ShoppingCart" className="h-5 w-5" />
          {cartCount > 0 && (
            <span className="absolute -right-1 -top-1 grid h-4 min-w-4 place-items-center rounded-full bg-primary px-1 text-[10px] font-bold text-primary-foreground">
              {cartCount}
            </span>
          )}
        </button>
      )}
    </header>
  );
}
