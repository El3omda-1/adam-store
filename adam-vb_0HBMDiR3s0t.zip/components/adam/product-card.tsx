"use client";

import { useAdam } from "@/contexts/adam-context";
import type { Product } from "@/lib/adam/types";
import { fmtPi } from "@/lib/adam/types";
import { Icon, Stars } from "./ui-bits";
import { cn } from "@/lib/utils";

export function ProductCard({
  product,
  view = "grid",
}: {
  product: Product;
  view?: "grid" | "list";
}) {
  const { navigate, toggleWishlist, isWishlisted, addToCart } = useAdam();
  const wished = isWishlisted(product.id);
  const discount = product.originalPrice
    ? Math.round(
        ((product.originalPrice - product.price) / product.originalPrice) * 100
      )
    : 0;

  if (view === "list") {
    return (
      <div
        className="flex gap-3 rounded-2xl bg-card border border-border p-3 active-press"
        onClick={() => navigate("product", product.id)}
      >
        <div className="relative h-24 w-24 shrink-0 overflow-hidden rounded-xl bg-secondary">
          <img
            src={product.image || "/placeholder.svg"}
            alt={product.name}
            className="h-full w-full object-cover"
          />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="text-sm font-semibold text-foreground line-clamp-2">
            {product.name}
          </h3>
          <div className="mt-1 flex items-center gap-1.5">
            <Stars rating={product.rating} size={12} />
            <span className="text-xs text-muted-foreground">
              ({product.reviewCount.toLocaleString()})
            </span>
          </div>
          <div className="mt-1.5 flex items-center gap-2">
            <span className="font-bold text-foreground">
              {fmtPi(product.price)}
            </span>
            {product.originalPrice && (
              <span className="text-xs text-muted-foreground line-through">
                {fmtPi(product.originalPrice)}
              </span>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="group flex flex-col overflow-hidden rounded-2xl bg-card border border-border ad-fade-up">
      <div
        className="relative aspect-square overflow-hidden bg-secondary active-press"
        onClick={() => navigate("product", product.id)}
      >
        <img
          src={product.image || "/placeholder.svg"}
          alt={product.name}
          className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
        />
        {discount > 0 && (
          <span className="absolute left-2 top-2 rounded-full bg-primary px-2 py-0.5 text-[10px] font-bold text-primary-foreground">
            -{discount}%
          </span>
        )}
        {product.flashDeal && (
          <span className="absolute left-2 bottom-2 inline-flex items-center gap-0.5 rounded-full bg-accent px-2 py-0.5 text-[10px] font-bold text-accent-foreground">
            <Icon name="Zap" className="h-3 w-3" /> Flash
          </span>
        )}
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleWishlist(product.id);
          }}
          aria-label="Toggle wishlist"
          className="absolute right-2 top-2 grid h-8 w-8 place-items-center rounded-full bg-card/90 backdrop-blur active-press"
        >
          <Icon
            name="Heart"
            className={cn(
              "h-4 w-4",
              wished ? "fill-primary text-primary" : "text-muted-foreground"
            )}
          />
        </button>
      </div>
      <div className="flex flex-1 flex-col p-3">
        <h3
          className="text-sm font-semibold text-foreground line-clamp-2 leading-snug active-press"
          onClick={() => navigate("product", product.id)}
        >
          {product.name}
        </h3>
        <div className="mt-1 flex items-center gap-1">
          <Stars rating={product.rating} size={11} />
          <span className="text-[11px] text-muted-foreground">
            ({product.reviewCount > 999 ? "1k+" : product.reviewCount})
          </span>
        </div>
        <div className="mt-auto pt-2 flex items-end justify-between">
          <div>
            <div className="font-bold text-foreground">
              {fmtPi(product.price)}
            </div>
            {product.originalPrice && (
              <div className="text-[11px] text-muted-foreground line-through">
                {fmtPi(product.originalPrice)}
              </div>
            )}
          </div>
          <button
            onClick={(e) => {
              e.stopPropagation();
              addToCart(product.id);
            }}
            aria-label="Add to cart"
            className="grid h-9 w-9 place-items-center rounded-full bg-primary text-primary-foreground active-press"
          >
            <Icon name="Plus" className="h-5 w-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
