"use client";

import { useAdam } from "@/contexts/adam-context";
import { Icon } from "./ui-bits";
import { cn } from "@/lib/utils";

export function ToastHost() {
  const { toasts } = useAdam();
  return (
    <div className="pointer-events-none fixed inset-x-0 top-3 z-[100] flex flex-col items-center gap-2 px-4">
      {toasts.map((t) => (
        <div
          key={t.id}
          className={cn(
            "ad-pop pointer-events-auto flex items-center gap-2 rounded-full px-4 py-2.5 text-sm font-semibold shadow-lg",
            t.tone === "success" && "bg-positive text-positive-foreground",
            t.tone === "error" && "bg-destructive text-destructive-foreground",
            t.tone === "default" && "bg-foreground text-background"
          )}
        >
          <Icon
            name={
              t.tone === "success"
                ? "CircleCheck"
                : t.tone === "error"
                ? "CircleAlert"
                : "Info"
            }
            className="h-4 w-4"
          />
          {t.message}
        </div>
      ))}
    </div>
  );
}
