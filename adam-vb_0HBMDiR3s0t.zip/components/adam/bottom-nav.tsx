"use client";

import { useAdam, type Tab } from "@/contexts/adam-context";
import { Icon } from "./ui-bits";
import { cn } from "@/lib/utils";

const TABS: { id: Tab; label: string; icon: string }[] = [
  { id: "home", label: "Home", icon: "House" },
  { id: "categories", label: "Categories", icon: "LayoutGrid" },
  { id: "cart", label: "Cart", icon: "ShoppingCart" },
  { id: "wishlist", label: "Wishlist", icon: "Heart" },
  { id: "account", label: "Account", icon: "User" },
];

export function BottomNav() {
  const { tab, setTab, cartCount, state } = useAdam();
  return (
    <nav className="shrink-0 border-t border-border bg-card/95 backdrop-blur">
      <div className="flex items-center justify-around px-2 pb-[env(safe-area-inset-bottom)]">
        {TABS.map((t) => {
          const active = tab === t.id;
          const badge =
            t.id === "cart"
              ? cartCount
              : t.id === "wishlist"
              ? state.wishlist.length
              : 0;
          return (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className="relative flex flex-1 flex-col items-center gap-0.5 py-2.5 active-press"
            >
              <div className="relative">
                <Icon
                  name={t.icon}
                  className={cn(
                    "h-6 w-6 transition-colors",
                    active ? "text-primary" : "text-muted-foreground"
                  )}
                  strokeWidth={active ? 2.4 : 2}
                />
                {badge > 0 && (
                  <span className="absolute -right-2 -top-1.5 grid h-4 min-w-4 place-items-center rounded-full bg-primary px-1 text-[10px] font-bold text-primary-foreground">
                    {badge > 9 ? "9+" : badge}
                  </span>
                )}
              </div>
              <span
                className={cn(
                  "text-[10px] font-semibold",
                  active ? "text-primary" : "text-muted-foreground"
                )}
              >
                {t.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
