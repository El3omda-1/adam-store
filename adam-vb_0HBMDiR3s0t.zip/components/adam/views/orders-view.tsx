"use client";

import { useAdam } from "@/contexts/adam-context";
import { fmtPi, fmtDate, type OrderStatus } from "@/lib/adam/types";
import { Icon, Button, Badge, EmptyState } from "../ui-bits";

const STATUS_META: Record<
  OrderStatus,
  { label: string; tone: "primary" | "accent" | "positive" | "danger" | "muted" }
> = {
  pending: { label: "Pending", tone: "muted" },
  confirmed: { label: "Confirmed", tone: "primary" },
  shipped: { label: "Shipped", tone: "accent" },
  delivered: { label: "Delivered", tone: "positive" },
  returned: { label: "Returned", tone: "muted" },
  cancelled: { label: "Cancelled", tone: "danger" },
};

export function OrdersView() {
  const { state, navigate, setTab } = useAdam();

  if (state.orders.length === 0) {
    return (
      <EmptyState
        icon="Package"
        title="No orders yet"
        subtitle="When you place an order it will appear here."
      >
        <Button onClick={() => setTab("home")}>Start shopping</Button>
      </EmptyState>
    );
  }

  return (
    <div className="space-y-3 p-4">
      {state.orders.map((o) => {
        const meta = STATUS_META[o.status];
        return (
          <button
            key={o.id}
            onClick={() => navigate("order-detail", o.id)}
            className="w-full rounded-2xl border border-border bg-card p-3.5 text-left active-press"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-muted-foreground">
                #{o.trackingNumber}
              </span>
              <Badge tone={meta.tone}>{meta.label}</Badge>
            </div>
            <div className="mt-2 flex items-center gap-2">
              <div className="flex -space-x-3">
                {o.lines.slice(0, 3).map((l) => (
                  <img
                    key={l.productId}
                    src={l.image || "/placeholder.svg"}
                    alt={l.name}
                    className="h-11 w-11 rounded-lg border-2 border-card bg-secondary object-cover"
                  />
                ))}
              </div>
              <div className="flex-1">
                <div className="text-sm font-semibold text-foreground">
                  {o.lines.length} item{o.lines.length > 1 ? "s" : ""}
                </div>
                <div className="text-xs text-muted-foreground">
                  {fmtDate(o.date)}
                </div>
              </div>
              <span className="font-bold text-primary">{fmtPi(o.total)}</span>
            </div>
          </button>
        );
      })}
    </div>
  );
}
