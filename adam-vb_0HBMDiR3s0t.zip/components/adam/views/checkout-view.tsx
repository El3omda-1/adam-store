"use client";

import { useState } from "react";
import { useAdam } from "@/contexts/adam-context";
import { getProduct } from "@/lib/adam/data";
import { fmtPi, POINTS_TO_PI } from "@/lib/adam/types";
import { Icon, Button, Spinner } from "../ui-bits";
import { cn } from "@/lib/utils";

export function CheckoutView() {
  const {
    state,
    cartSubtotal,
    placeOrder,
    navigate,
    setTab,
    showToast,
  } = useAdam();

  const [addressId, setAddressId] = useState(state.addresses[0]?.id ?? "");
  const [usesPoints, setUsesPoints] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [done, setDone] = useState<null | { id: string; tracking: string; points: number; total: number }>(null);

  const maxRedeemable = Math.min(
    state.loyaltyPoints,
    Math.floor(cartSubtotal * POINTS_TO_PI)
  );
  const pointsToRedeem = usesPoints ? maxRedeemable : 0;
  const discount = pointsToRedeem / POINTS_TO_PI;
  const shipping = cartSubtotal > 50 ? 0 : 1.5;
  const taxable = Math.max(0, cartSubtotal - discount);
  const tax = +(taxable * 0.05).toFixed(2);
  const total = +(taxable + shipping + tax).toFixed(2);

  const address = state.addresses.find((a) => a.id === addressId);

  const handlePay = async () => {
    if (!address) {
      showToast("Please select an address", "error");
      return;
    }
    setProcessing(true);
    const addrStr = `${address.recipient}, ${address.line}, ${address.city}`;
    const res = await placeOrder({ address: addrStr, pointsToRedeem });
    setProcessing(false);
    if (res.ok && res.order) {
      setDone({
        id: res.order.id,
        tracking: res.order.trackingNumber,
        points: res.order.pointsEarned,
        total: res.order.total,
      });
    } else if (res.reason === "cancelled") {
      showToast("Payment cancelled", "error");
    } else if (res.reason === "empty") {
      showToast("Your cart is empty", "error");
    } else {
      showToast("Could not complete order", "error");
    }
  };

  if (done) {
    return (
      <div className="flex flex-col items-center justify-center px-6 py-16 text-center">
        <div className="grid h-20 w-20 place-items-center rounded-full bg-positive text-positive-foreground ad-pop">
          <Icon name="Check" className="h-10 w-10" strokeWidth={3} />
        </div>
        <h1 className="mt-5 text-2xl font-extrabold text-foreground">
          Order confirmed!
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Thank you for shopping with Adam.
        </p>
        <div className="mt-5 w-full space-y-2 rounded-2xl border border-border bg-card p-4 text-left">
          <Row label="Tracking number" value={done.tracking} />
          <Row label="Total paid" value={fmtPi(done.total)} />
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Points earned</span>
            <span className="inline-flex items-center gap-1 text-sm font-bold text-accent-foreground">
              <Icon name="Award" className="h-4 w-4 text-accent" />+{done.points}
            </span>
          </div>
        </div>
        <div className="mt-5 flex w-full gap-2">
          <Button
            variant="outline"
            className="flex-1"
            onClick={() => {
              setTab("home");
            }}
          >
            Keep shopping
          </Button>
          <Button
            className="flex-1"
            onClick={() => {
              navigate("orders");
            }}
          >
            View orders
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5 p-4 pb-32">
      {/* address */}
      <section>
        <div className="mb-2 flex items-center justify-between">
          <h2 className="font-bold text-foreground">Delivery address</h2>
          <button
            onClick={() => navigate("addresses")}
            className="text-sm font-semibold text-primary active-press"
          >
            Manage
          </button>
        </div>
        <div className="space-y-2">
          {state.addresses.map((a) => (
            <button
              key={a.id}
              onClick={() => setAddressId(a.id)}
              className={cn(
                "flex w-full items-start gap-3 rounded-2xl border p-3 text-left active-press",
                addressId === a.id
                  ? "border-primary bg-primary/5"
                  : "border-border bg-card"
              )}
            >
              <Icon
                name={addressId === a.id ? "CircleCheck" : "Circle"}
                className={cn(
                  "mt-0.5 h-5 w-5 shrink-0",
                  addressId === a.id ? "text-primary" : "text-muted-foreground"
                )}
              />
              <div>
                <div className="text-sm font-bold text-foreground">
                  {a.label} · {a.recipient}
                </div>
                <div className="text-xs text-muted-foreground">
                  {a.line}, {a.city}
                </div>
                <div className="text-xs text-muted-foreground">{a.phone}</div>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* items */}
      <section>
        <h2 className="mb-2 font-bold text-foreground">
          Items ({state.cart.length})
        </h2>
        <div className="space-y-2 rounded-2xl border border-border bg-card p-3">
          {state.cart.map((item) => {
            const p = getProduct(item.productId);
            if (!p) return null;
            return (
              <div key={item.productId} className="flex items-center gap-3">
                <img
                  src={p.image || "/placeholder.svg"}
                  alt={p.name}
                  className="h-12 w-12 rounded-lg bg-secondary object-cover"
                />
                <span className="flex-1 truncate text-sm text-foreground">
                  {p.name}
                </span>
                <span className="text-xs text-muted-foreground">
                  x{item.qty}
                </span>
                <span className="text-sm font-semibold text-foreground">
                  {fmtPi(p.price * item.qty)}
                </span>
              </div>
            );
          })}
        </div>
      </section>

      {/* loyalty points */}
      {maxRedeemable > 0 && (
        <button
          onClick={() => setUsesPoints((v) => !v)}
          className="flex w-full items-center gap-3 rounded-2xl border border-border bg-card p-3.5 text-left active-press"
        >
          <div className="grid h-10 w-10 place-items-center rounded-xl bg-accent text-accent-foreground">
            <Icon name="Award" className="h-5 w-5" />
          </div>
          <div className="flex-1">
            <div className="text-sm font-bold text-foreground">
              Redeem {maxRedeemable} points
            </div>
            <div className="text-xs text-muted-foreground">
              Save {fmtPi(maxRedeemable / POINTS_TO_PI)} on this order
            </div>
          </div>
          <div
            className={cn(
              "flex h-6 w-11 items-center rounded-full p-0.5 transition-colors",
              usesPoints ? "bg-primary" : "bg-muted"
            )}
          >
            <div
              className={cn(
                "h-5 w-5 rounded-full bg-card transition-transform",
                usesPoints && "translate-x-5"
              )}
            />
          </div>
        </button>
      )}

      {/* summary */}
      <section className="space-y-1 rounded-2xl border border-border bg-card p-4 text-sm">
        <Row label="Subtotal" value={fmtPi(cartSubtotal)} />
        {discount > 0 && (
          <Row label="Points discount" value={`- ${fmtPi(discount)}`} positive />
        )}
        <Row label="Shipping" value={shipping === 0 ? "Free" : fmtPi(shipping)} />
        <Row label="Tax (5%)" value={fmtPi(tax)} />
        <div className="flex items-center justify-between border-t border-border pt-2 text-base font-extrabold text-foreground">
          <span>Total</span>
          <span className="text-primary">{fmtPi(total)}</span>
        </div>
      </section>

      {/* pay */}
      <div className="fixed inset-x-0 bottom-0 z-40 mx-auto max-w-md border-t border-border bg-card/95 p-4 pb-[max(1rem,env(safe-area-inset-bottom))] backdrop-blur">
        <Button
          className="w-full"
          size="lg"
          disabled={processing || state.cart.length === 0}
          onClick={handlePay}
        >
          {processing ? (
            <>
              <Spinner className="h-5 w-5 border-primary-foreground/40 border-t-primary-foreground" />
              Processing…
            </>
          ) : (
            <>
              <Icon name="Wallet" className="h-5 w-5" /> Pay {fmtPi(total)} with Pi
            </>
          )}
        </Button>
      </div>
    </div>
  );
}

function Row({
  label,
  value,
  positive,
}: {
  label: string;
  value: string;
  positive?: boolean;
}) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span
        className={cn(
          "font-semibold",
          positive ? "text-positive" : "text-foreground"
        )}
      >
        {value}
      </span>
    </div>
  );
}
