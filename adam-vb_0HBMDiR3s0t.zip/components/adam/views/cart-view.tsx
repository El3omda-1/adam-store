"use client";

import { useAdam } from "@/contexts/adam-context";
import { getProduct } from "@/lib/adam/data";
import { fmtPi } from "@/lib/adam/types";
import { Icon, Button, EmptyState } from "../ui-bits";

export function CartView() {
  const {
    state,
    setQty,
    removeFromCart,
    saveForLater,
    moveToCart,
    cartSubtotal,
    navigate,
    setTab,
  } = useAdam();

  const shipping = cartSubtotal > 50 ? 0 : cartSubtotal > 0 ? 1.5 : 0;
  const tax = +(cartSubtotal * 0.05).toFixed(2);
  const total = +(cartSubtotal + shipping + tax).toFixed(2);

  if (state.cart.length === 0 && state.savedForLater.length === 0) {
    return (
      <EmptyState
        icon="ShoppingCart"
        title="Your cart is empty"
        subtitle="Browse products and add your favourites to the cart."
      >
        <Button onClick={() => setTab("home")}>
          <Icon name="Store" className="h-4 w-4" /> Start shopping
        </Button>
      </EmptyState>
    );
  }

  return (
    <div className="pb-40">
      <div className="space-y-3 p-4">
        {state.cart.map((item) => {
          const p = getProduct(item.productId);
          if (!p) return null;
          return (
            <div
              key={item.productId}
              className="flex gap-3 rounded-2xl border border-border bg-card p-3"
            >
              <button
                onClick={() => navigate("product", p.id)}
                className="h-20 w-20 shrink-0 overflow-hidden rounded-xl bg-secondary active-press"
              >
                <img
                  src={p.image || "/placeholder.svg"}
                  alt={p.name}
                  className="h-full w-full object-cover"
                />
              </button>
              <div className="flex flex-1 flex-col">
                <div className="flex items-start justify-between gap-2">
                  <h3 className="text-sm font-semibold text-foreground line-clamp-2">
                    {p.name}
                  </h3>
                  <button
                    onClick={() => removeFromCart(item.productId)}
                    aria-label="Remove"
                    className="shrink-0 text-muted-foreground active-press"
                  >
                    <Icon name="Trash2" className="h-4 w-4" />
                  </button>
                </div>
                <span className="text-sm font-bold text-primary">
                  {fmtPi(p.price)}
                </span>
                <div className="mt-auto flex items-center justify-between pt-1">
                  <div className="flex items-center gap-2 rounded-full border border-border">
                    <button
                      onClick={() => setQty(item.productId, item.qty - 1)}
                      className="grid h-7 w-7 place-items-center active-press"
                      aria-label="Decrease"
                    >
                      <Icon name="Minus" className="h-3.5 w-3.5" />
                    </button>
                    <span className="min-w-5 text-center text-sm font-bold">
                      {item.qty}
                    </span>
                    <button
                      onClick={() => setQty(item.productId, item.qty + 1)}
                      className="grid h-7 w-7 place-items-center active-press"
                      aria-label="Increase"
                    >
                      <Icon name="Plus" className="h-3.5 w-3.5" />
                    </button>
                  </div>
                  <button
                    onClick={() => saveForLater(item.productId)}
                    className="text-xs font-semibold text-primary active-press"
                  >
                    Save for later
                  </button>
                </div>
              </div>
            </div>
          );
        })}

        {/* saved for later */}
        {state.savedForLater.length > 0 && (
          <div className="pt-2">
            <h2 className="mb-2 font-bold text-foreground">
              Saved for later ({state.savedForLater.length})
            </h2>
            <div className="space-y-3">
              {state.savedForLater.map((id) => {
                const p = getProduct(id);
                if (!p) return null;
                return (
                  <div
                    key={id}
                    className="flex items-center gap-3 rounded-2xl border border-border bg-card p-3"
                  >
                    <img
                      src={p.image || "/placeholder.svg"}
                      alt={p.name}
                      className="h-14 w-14 rounded-xl bg-secondary object-cover"
                    />
                    <div className="min-w-0 flex-1">
                      <h3 className="truncate text-sm font-semibold text-foreground">
                        {p.name}
                      </h3>
                      <span className="text-sm font-bold text-primary">
                        {fmtPi(p.price)}
                      </span>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => moveToCart(id)}
                    >
                      Move to cart
                    </Button>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* summary + checkout */}
      {state.cart.length > 0 && (
        <div className="fixed inset-x-0 bottom-0 z-40 mx-auto max-w-md border-t border-border bg-card/95 p-4 pb-[max(1rem,env(safe-area-inset-bottom))] backdrop-blur">
          <div className="mb-3 space-y-1 text-sm">
            <Row label="Subtotal" value={fmtPi(cartSubtotal)} />
            <Row
              label="Shipping"
              value={shipping === 0 ? "Free" : fmtPi(shipping)}
            />
            <Row label="Tax (5%)" value={fmtPi(tax)} />
            <div className="flex items-center justify-between border-t border-border pt-2 text-base font-extrabold text-foreground">
              <span>Total</span>
              <span className="text-primary">{fmtPi(total)}</span>
            </div>
          </div>
          <Button className="w-full" size="lg" onClick={() => navigate("checkout")}>
            Proceed to checkout
            <Icon name="ArrowRight" className="h-5 w-5" />
          </Button>
        </div>
      )}
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between text-muted-foreground">
      <span>{label}</span>
      <span className="font-semibold text-foreground">{value}</span>
    </div>
  );
}
