"use client";

import { useAdam } from "@/contexts/adam-context";
import { PRODUCTS, CATEGORIES, getProduct } from "@/lib/adam/data";
import { ProductCard } from "../product-card";
import { Icon, SectionTitle } from "../ui-bits";
import { fmtPi } from "@/lib/adam/types";

export function HomeView() {
  const { navigate, setTab, state } = useAdam();

  const flashDeals = PRODUCTS.filter((p) => p.flashDeal);
  const trending = PRODUCTS.filter((p) => p.trending);
  const featured = PRODUCTS.filter((p) => p.featured);
  const recently = state.recentlyViewed
    .map((id) => getProduct(id))
    .filter(Boolean)
    .slice(0, 8);

  return (
    <div className="space-y-6 pb-6">
      {/* hero banner */}
      <div className="px-4 pt-4">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary to-accent p-5 text-primary-foreground">
          <div className="relative z-10 max-w-[70%]">
            <span className="inline-flex items-center gap-1 rounded-full bg-primary-foreground/20 px-2.5 py-1 text-[11px] font-bold">
              <Icon name="Zap" className="h-3 w-3" /> Mega Sale
            </span>
            <h2 className="mt-2 text-2xl font-extrabold leading-tight text-balance">
              Up to 40% off everything
            </h2>
            <p className="mt-1 text-sm opacity-90">
              Earn loyalty points on every Pi purchase.
            </p>
            <button
              onClick={() => navigate("deals")}
              className="mt-3 inline-flex items-center gap-1 rounded-full bg-primary-foreground px-4 py-2 text-sm font-bold text-primary active-press"
            >
              Shop deals <Icon name="ArrowRight" className="h-4 w-4" />
            </button>
          </div>
          <Icon
            name="ShoppingBag"
            className="absolute -right-4 -bottom-4 h-36 w-36 opacity-15"
          />
        </div>
      </div>

      {/* loyalty strip */}
      <div className="px-4">
        <button
          onClick={() => navigate("profile")}
          className="flex w-full items-center justify-between rounded-2xl border border-border bg-card p-3.5 active-press"
        >
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-accent text-accent-foreground">
              <Icon name="Award" className="h-5 w-5" />
            </div>
            <div className="text-left">
              <div className="text-sm font-bold text-foreground">
                {state.loyaltyPoints.toLocaleString()} points
              </div>
              <div className="text-xs text-muted-foreground">
                Redeem for {fmtPi(state.loyaltyPoints / 100)} off
              </div>
            </div>
          </div>
          <Icon name="ChevronRight" className="h-5 w-5 text-muted-foreground" />
        </button>
      </div>

      {/* categories row */}
      <div>
        <div className="px-4">
          <SectionTitle
            title="Categories"
            action="See all"
            onAction={() => setTab("categories")}
          />
        </div>
        <div className="flex gap-3 overflow-x-auto px-4 no-scrollbar">
          {CATEGORIES.map((c) => (
            <button
              key={c.id}
              onClick={() => navigate("category", c.id)}
              className="flex w-16 shrink-0 flex-col items-center gap-1.5 active-press"
            >
              <div
                className="grid h-16 w-16 place-items-center rounded-2xl"
                style={{
                  backgroundColor: `oklch(0.95 0.05 ${c.hue})`,
                  color: `oklch(0.45 0.15 ${c.hue})`,
                }}
              >
                <Icon name={c.icon} className="h-7 w-7" />
              </div>
              <span className="text-[11px] font-medium text-foreground text-center leading-tight">
                {c.name}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* flash deals */}
      <div>
        <div className="px-4">
          <SectionTitle
            title="⚡ Flash Deals"
            action="View all"
            onAction={() => navigate("deals")}
          />
        </div>
        <div className="flex gap-3 overflow-x-auto px-4 pb-1 no-scrollbar">
          {flashDeals.map((p) => (
            <div key={p.id} className="w-40 shrink-0">
              <ProductCard product={p} />
            </div>
          ))}
        </div>
      </div>

      {/* trending */}
      <div className="px-4">
        <SectionTitle title="🔥 Trending now" />
        <div className="grid grid-cols-2 gap-3">
          {trending.slice(0, 6).map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </div>

      {/* recently viewed */}
      {recently.length > 0 && (
        <div>
          <div className="px-4">
            <SectionTitle title="Recently viewed" />
          </div>
          <div className="flex gap-3 overflow-x-auto px-4 pb-1 no-scrollbar">
            {recently.map(
              (p) =>
                p && (
                  <div key={p.id} className="w-36 shrink-0">
                    <ProductCard product={p} />
                  </div>
                )
            )}
          </div>
        </div>
      )}

      {/* featured */}
      <div className="px-4">
        <SectionTitle title="Featured picks" />
        <div className="grid grid-cols-2 gap-3">
          {featured.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </div>
    </div>
  );
}
