"use client";

import { useAdam } from "@/contexts/adam-context";
import { getProduct, getSeller } from "@/lib/adam/data";
import { Button, Icon, Stars, EmptyState } from "@/components/adam/ui-bits";
import { fmtPi } from "@/lib/adam/types";

export function CompareView() {
  const { state, toggleCompare, navigate, addToCart } = useAdam();
  const products = state.compare
    .map((id) => getProduct(id))
    .filter(Boolean) as NonNullable<ReturnType<typeof getProduct>>[];

  if (products.length === 0) {
    return (
      <EmptyState
        icon="GitCompare"
        title="Nothing to compare"
        subtitle="Add up to 4 products to compare specs, prices and ratings side by side."
      >
        <Button onClick={() => navigate("category", "electronics")}>
          Browse products
        </Button>
      </EmptyState>
    );
  }

  const rows: { label: string; render: (p: (typeof products)[number]) => string }[] = [
    { label: "Price", render: (p) => fmtPi(p.price) },
    { label: "Brand", render: (p) => p.brand },
    { label: "Rating", render: (p) => `${p.rating} (${p.reviewCount})` },
    { label: "Seller", render: (p) => getSeller(p.sellerId)?.name ?? "—" },
    { label: "Stock", render: (p) => (p.stock > 0 ? `${p.stock} left` : "Out of stock") },
  ];

  // gather all spec labels
  const specLabels = Array.from(
    new Set(products.flatMap((p) => p.specs.map((s) => s.label)))
  );

  return (
    <div className="px-4 py-4">
      <p className="text-sm text-muted-foreground mb-3">
        Comparing {products.length} of 4 products
      </p>
      <div className="overflow-x-auto no-scrollbar -mx-4 px-4">
        <table className="w-full border-collapse" style={{ minWidth: products.length * 150 }}>
          <thead>
            <tr>
              <th className="w-20 sticky left-0 bg-background" />
              {products.map((p) => (
                <th key={p.id} className="p-2 align-top">
                  <div className="relative rounded-xl bg-card border border-border p-2">
                    <button
                      onClick={() => toggleCompare(p.id)}
                      className="absolute -top-2 -right-2 h-6 w-6 rounded-full bg-destructive text-destructive-foreground flex items-center justify-center active-press"
                      aria-label="Remove"
                    >
                      <Icon name="X" className="h-3.5 w-3.5" />
                    </button>
                    <img
                      src={p.image || "/placeholder.svg"}
                      alt={p.name}
                      className="h-20 w-full object-cover rounded-lg mb-1.5"
                    />
                    <p className="text-xs font-semibold text-foreground line-clamp-2 text-left">
                      {p.name}
                    </p>
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.label} className="border-t border-border">
                <td className="text-xs font-semibold text-muted-foreground py-2.5 pr-2 sticky left-0 bg-background align-top">
                  {row.label}
                </td>
                {products.map((p) => (
                  <td key={p.id} className="text-xs text-foreground py-2.5 px-2 align-top">
                    {row.label === "Rating" ? (
                      <div className="flex flex-col gap-1">
                        <Stars rating={p.rating} size={12} />
                        <span>{row.render(p)}</span>
                      </div>
                    ) : (
                      row.render(p)
                    )}
                  </td>
                ))}
              </tr>
            ))}
            {specLabels.map((label) => (
              <tr key={label} className="border-t border-border">
                <td className="text-xs font-semibold text-muted-foreground py-2.5 pr-2 sticky left-0 bg-background align-top">
                  {label}
                </td>
                {products.map((p) => (
                  <td key={p.id} className="text-xs text-foreground py-2.5 px-2 align-top">
                    {p.specs.find((s) => s.label === label)?.value ?? "—"}
                  </td>
                ))}
              </tr>
            ))}
            <tr className="border-t border-border">
              <td className="sticky left-0 bg-background" />
              {products.map((p) => (
                <td key={p.id} className="py-3 px-2 align-top">
                  <Button size="sm" className="w-full" onClick={() => addToCart(p.id)}>
                    Add
                  </Button>
                </td>
              ))}
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}
