"use client";

import { useAdam } from "@/contexts/adam-context";
import { getProduct } from "@/lib/adam/data";
import { ProductCard } from "../product-card";
import { Icon, Button, EmptyState } from "../ui-bits";

export function WishlistView() {
  const { state, setTab } = useAdam();
  const items = state.wishlist.map((id) => getProduct(id)).filter(Boolean);

  if (items.length === 0) {
    return (
      <EmptyState
        icon="Heart"
        title="No saved items"
        subtitle="Tap the heart on any product to save it here."
      >
        <Button onClick={() => setTab("home")}>
          <Icon name="Store" className="h-4 w-4" /> Explore products
        </Button>
      </EmptyState>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-3 p-4">
      {items.map((p) => p && <ProductCard key={p.id} product={p} />)}
    </div>
  );
}
