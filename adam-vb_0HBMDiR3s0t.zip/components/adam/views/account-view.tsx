"use client";

import { usePiAuth } from "@/contexts/pi-auth-context";
import { useAdam } from "@/contexts/adam-context";
import { tierFor, fmtPi } from "@/lib/adam/types";
import { Icon } from "../ui-bits";

export function AccountView() {
  const { state, navigate, setTab } = useAdam();
  const { current } = tierFor(state.totalSpent);

  const rows: {
    icon: string;
    label: string;
    sub?: string;
    onPress: () => void;
  }[] = [
    { icon: "Package", label: "My Orders", sub: `${state.orders.length} orders`, onPress: () => navigate("orders") },
    { icon: "Award", label: "Loyalty & Rewards", sub: `${state.loyaltyPoints} points`, onPress: () => navigate("profile") },
    { icon: "Heart", label: "Wishlist", sub: `${state.wishlist.length} items`, onPress: () => setTab("wishlist") },
    { icon: "GitCompare", label: "Compare", sub: `${state.compare.length} products`, onPress: () => navigate("compare") },
    { icon: "MapPin", label: "Addresses", sub: `${state.addresses.length} saved`, onPress: () => navigate("addresses") },
    { icon: "Settings", label: "Settings", onPress: () => navigate("settings") },
  ];

  return (
    <div className="space-y-4 p-4">
      <ProfileHeader tier={current.name} hue={current.hue} />

      <div className="grid grid-cols-3 gap-3">
        <Stat
          label="Orders"
          value={String(state.orders.length)}
          icon="Package"
          onClick={() => navigate("orders")}
        />
        <Stat
          label="Points"
          value={state.loyaltyPoints.toLocaleString()}
          icon="Award"
          onClick={() => navigate("profile")}
        />
        <Stat
          label="Spent"
          value={fmtPi(state.totalSpent)}
          icon="Wallet"
        />
      </div>

      <div className="overflow-hidden rounded-2xl border border-border bg-card">
        {rows.map((r, i) => (
          <button
            key={r.label}
            onClick={r.onPress}
            className="flex w-full items-center gap-3 px-4 py-3.5 text-left active-press"
          >
            <div className="grid h-9 w-9 place-items-center rounded-lg bg-secondary text-foreground">
              <Icon name={r.icon} className="h-5 w-5" />
            </div>
            <div className="flex-1">
              <div className="text-sm font-semibold text-foreground">
                {r.label}
              </div>
              {r.sub && (
                <div className="text-xs text-muted-foreground">{r.sub}</div>
              )}
            </div>
            <Icon name="ChevronRight" className="h-5 w-5 text-muted-foreground" />
          </button>
        ))}
      </div>
    </div>
  );
}

function ProfileHeader({ tier, hue }: { tier: string; hue: number }) {
  const { sdk } = usePiAuth();
  // username may not be exposed by SDKLite; use a friendly default
  const name = "Pi Pioneer";
  return (
    <div className="flex items-center gap-3 rounded-2xl bg-gradient-to-br from-primary to-accent p-4 text-primary-foreground">
      <div className="grid h-14 w-14 place-items-center rounded-full bg-primary-foreground/20 text-xl font-extrabold">
        {name.charAt(0)}
      </div>
      <div className="flex-1">
        <div className="text-lg font-extrabold">{name}</div>
        <span
          className="mt-0.5 inline-flex items-center gap-1 rounded-full bg-primary-foreground/20 px-2 py-0.5 text-xs font-bold"
        >
          <Icon name="Crown" className="h-3.5 w-3.5" /> {tier} member
        </span>
      </div>
      <Icon name="ShieldCheck" className="h-6 w-6 opacity-80" />
    </div>
  );
}

function Stat({
  label,
  value,
  icon,
  onClick,
}: {
  label: string;
  value: string;
  icon: string;
  onClick?: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="flex flex-col items-center gap-1 rounded-2xl border border-border bg-card py-3 active-press"
    >
      <Icon name={icon} className="h-5 w-5 text-primary" />
      <span className="text-sm font-bold text-foreground">{value}</span>
      <span className="text-[11px] text-muted-foreground">{label}</span>
    </button>
  );
}
