"use client";

import { useAdam } from "@/contexts/adam-context";
import { getSeller, PRODUCTS } from "@/lib/adam/data";
import { ProductCard } from "@/components/adam/product-card";
import { Card, Icon, Stars, Badge, EmptyState, Button } from "@/components/adam/ui-bits";

export function SellerView({ sellerId }: { sellerId: string }) {
  const { showToast } = useAdam();
  const seller = getSeller(sellerId);
  const products = PRODUCTS.filter((p) => p.sellerId === sellerId);

  if (!seller) {
    return <EmptyState icon="Store" title="Seller not found" />;
  }

  return (
    <div className="pb-6">
      <div className="px-4 py-4">
        <Card className="p-4">
          <div className="flex items-start gap-4">
            <div className="h-16 w-16 rounded-2xl bg-primary/10 flex items-center justify-center shrink-0">
              <Icon name="Store" className="h-8 w-8 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-foreground truncate">
                  {seller.name}
                </h2>
                {seller.verified && (
                  <Badge tone="positive">
                    <Icon name="BadgeCheck" className="h-3 w-3" />
                    Verified
                  </Badge>
                )}
              </div>
              <div className="flex items-center gap-2 mt-1">
                <Stars rating={seller.rating} size={14} />
                <span className="text-sm font-semibold text-foreground">
                  {seller.rating}
                </span>
                <span className="text-xs text-muted-foreground">
                  ({seller.reviewCount.toLocaleString()})
                </span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Seller since {seller.joined}
              </p>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-2 mt-4">
            <div className="text-center bg-secondary rounded-xl py-2.5">
              <p className="font-bold text-foreground">{products.length}</p>
              <p className="text-xs text-muted-foreground">Products</p>
            </div>
            <div className="text-center bg-secondary rounded-xl py-2.5">
              <p className="font-bold text-foreground">{seller.rating}</p>
              <p className="text-xs text-muted-foreground">Rating</p>
            </div>
            <div className="text-center bg-secondary rounded-xl py-2.5">
              <p className="font-bold text-foreground">
                {(seller.reviewCount / 1000).toFixed(1)}k
              </p>
              <p className="text-xs text-muted-foreground">Reviews</p>
            </div>
          </div>
          <Button
            variant="outline"
            className="w-full mt-3"
            onClick={() => showToast("Messaging coming soon", "default")}
          >
            <Icon name="MessageCircle" className="h-4 w-4" />
            Contact seller
          </Button>
        </Card>
      </div>

      <div className="px-4">
        <h3 className="text-base font-bold text-foreground mb-3">
          Products from this seller
        </h3>
        <div className="grid grid-cols-2 gap-3">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </div>
    </div>
  );
}
