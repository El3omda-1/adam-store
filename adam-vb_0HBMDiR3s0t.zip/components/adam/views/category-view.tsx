"use client";

import { useState, useMemo } from "react";
import { useAdam } from "@/contexts/adam-context";
import { CATEGORIES, PRODUCTS } from "@/lib/adam/data";
import { ProductCard } from "../product-card";
import { Icon, Pill, EmptyState } from "../ui-bits";
import { cn } from "@/lib/utils";

type Sort = "relevance" | "price-asc" | "price-desc" | "rating" | "newest";

const SORTS: { id: Sort; label: string }[] = [
  { id: "relevance", label: "Relevance" },
  { id: "price-asc", label: "Price: Low to High" },
  { id: "price-desc", label: "Price: High to Low" },
  { id: "rating", label: "Top Rated" },
  { id: "newest", label: "Newest" },
];

export function CategoryView({ categoryId }: { categoryId: string }) {
  const { screen } = useAdam();
  const cat = CATEGORIES.find((c) => c.id === categoryId);
  const [sub, setSub] = useState<string>("All");
  const [sort, setSort] = useState<Sort>("relevance");
  const [view, setView] = useState<"grid" | "list">("grid");
  const [showSort, setShowSort] = useState(false);
  const [minRating, setMinRating] = useState(0);

  const products = useMemo(() => {
    let list = PRODUCTS.filter((p) => p.category === categoryId);
    if (sub !== "All") list = list.filter((p) => p.subcategory === sub);
    if (minRating > 0) list = list.filter((p) => p.rating >= minRating);
    switch (sort) {
      case "price-asc":
        list = [...list].sort((a, b) => a.price - b.price);
        break;
      case "price-desc":
        list = [...list].sort((a, b) => b.price - a.price);
        break;
      case "rating":
        list = [...list].sort((a, b) => b.rating - a.rating);
        break;
      case "newest":
        list = [...list].reverse();
        break;
    }
    return list;
  }, [categoryId, sub, sort, minRating]);

  if (!cat) return null;

  return (
    <div className="flex flex-col">
      <div className="px-4 pt-3">
        <h1 className="text-xl font-extrabold text-foreground flex items-center gap-2">
          <Icon name={cat.icon} className="h-5 w-5 text-primary" /> {cat.name}
        </h1>
        <p className="text-xs text-muted-foreground">
          {products.length} products
        </p>
      </div>

      {/* subcategory pills */}
      <div className="flex gap-2 overflow-x-auto px-4 py-3 no-scrollbar">
        <Pill active={sub === "All"} onClick={() => setSub("All")}>
          All
        </Pill>
        {cat.subcategories.map((s) => (
          <Pill key={s} active={sub === s} onClick={() => setSub(s)}>
            {s}
          </Pill>
        ))}
      </div>

      {/* toolbar */}
      <div className="flex items-center gap-2 border-y border-border px-4 py-2">
        <button
          onClick={() => setShowSort((v) => !v)}
          className="flex items-center gap-1 text-sm font-semibold text-foreground active-press"
        >
          <Icon name="ArrowUpDown" className="h-4 w-4" />
          {SORTS.find((s) => s.id === sort)?.label}
        </button>
        <div className="ml-auto flex items-center gap-1">
          <button
            onClick={() => setMinRating(minRating >= 4 ? 0 : 4)}
            className={cn(
              "flex items-center gap-1 rounded-full border px-2.5 py-1 text-xs font-semibold active-press",
              minRating >= 4
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border text-foreground"
            )}
          >
            <Icon name="Star" className="h-3.5 w-3.5" /> 4+
          </button>
          <button
            onClick={() => setView(view === "grid" ? "list" : "grid")}
            className="grid h-8 w-8 place-items-center rounded-full bg-secondary active-press"
          >
            <Icon name={view === "grid" ? "List" : "LayoutGrid"} className="h-4 w-4" />
          </button>
        </div>
      </div>

      {showSort && (
        <div className="border-b border-border bg-card px-4 py-2 ad-fade-in">
          {SORTS.map((s) => (
            <button
              key={s.id}
              onClick={() => {
                setSort(s.id);
                setShowSort(false);
              }}
              className={cn(
                "flex w-full items-center justify-between py-2 text-sm",
                sort === s.id
                  ? "font-bold text-primary"
                  : "text-foreground"
              )}
            >
              {s.label}
              {sort === s.id && <Icon name="Check" className="h-4 w-4" />}
            </button>
          ))}
        </div>
      )}

      {/* products */}
      <div className="p-4">
        {products.length === 0 ? (
          <EmptyState
            icon="PackageOpen"
            title="No products found"
            subtitle="Try adjusting your filters."
          />
        ) : view === "grid" ? (
          <div className="grid grid-cols-2 gap-3">
            {products.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        ) : (
          <div className="space-y-3">
            {products.map((p) => (
              <ProductCard key={p.id} product={p} view="list" />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
