"use client";

import { useState, useMemo, useRef, useEffect } from "react";
import { useAdam } from "@/contexts/adam-context";
import { PRODUCTS, TRENDING_SEARCHES, CATEGORIES } from "@/lib/adam/data";
import { ProductCard } from "../product-card";
import { Icon, Pill, EmptyState } from "../ui-bits";
import { inputClass } from "../ui-bits";

export function SearchView() {
  const { back } = useAdam();
  const [q, setQ] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [catFilter, setCatFilter] = useState<string>("All");
  const [maxPrice, setMaxPrice] = useState(200);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const suggestions = useMemo(() => {
    if (!q.trim() || submitted) return [];
    const lower = q.toLowerCase();
    const names = PRODUCTS.filter((p) =>
      p.name.toLowerCase().includes(lower)
    ).slice(0, 5);
    return names;
  }, [q, submitted]);

  const results = useMemo(() => {
    if (!q.trim()) return [];
    const lower = q.toLowerCase();
    let list = PRODUCTS.filter(
      (p) =>
        p.name.toLowerCase().includes(lower) ||
        p.brand.toLowerCase().includes(lower) ||
        p.category.includes(lower) ||
        p.subcategory.toLowerCase().includes(lower)
    );
    if (catFilter !== "All") list = list.filter((p) => p.category === catFilter);
    list = list.filter((p) => p.price <= maxPrice);
    return list;
  }, [q, catFilter, maxPrice]);

  return (
    <div className="flex flex-col">
      <div className="sticky top-0 z-10 flex items-center gap-2 border-b border-border bg-card px-3 py-2.5">
        <button
          onClick={back}
          aria-label="Back"
          className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-secondary active-press"
        >
          <Icon name="ChevronLeft" className="h-5 w-5" />
        </button>
        <div className="relative flex-1">
          <Icon
            name="Search"
            className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
          />
          <input
            ref={inputRef}
            value={q}
            onChange={(e) => {
              setQ(e.target.value);
              setSubmitted(false);
            }}
            onKeyDown={(e) => e.key === "Enter" && setSubmitted(true)}
            placeholder="Search products, brands…"
            className={`${inputClass} pl-9 pr-9`}
          />
          {q && (
            <button
              onClick={() => {
                setQ("");
                setSubmitted(false);
              }}
              className="absolute right-2 top-1/2 grid h-6 w-6 -translate-y-1/2 place-items-center rounded-full bg-secondary active-press"
            >
              <Icon name="X" className="h-3.5 w-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* autocomplete suggestions */}
      {suggestions.length > 0 && (
        <div className="border-b border-border bg-card">
          {suggestions.map((p) => (
            <button
              key={p.id}
              onClick={() => {
                setQ(p.name);
                setSubmitted(true);
              }}
              className="flex w-full items-center gap-2 px-4 py-2.5 text-left active-press"
            >
              <Icon name="Search" className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-foreground line-clamp-1">
                {p.name}
              </span>
            </button>
          ))}
        </div>
      )}

      {/* no query: trending */}
      {!q.trim() && (
        <div className="p-4">
          <h3 className="mb-3 text-sm font-bold text-foreground">
            Trending searches
          </h3>
          <div className="flex flex-wrap gap-2">
            {TRENDING_SEARCHES.map((t) => (
              <Pill
                key={t}
                onClick={() => {
                  setQ(t);
                  setSubmitted(true);
                }}
              >
                {t}
              </Pill>
            ))}
          </div>
        </div>
      )}

      {/* results */}
      {q.trim() && (
        <div className="flex flex-col">
          <div className="flex gap-2 overflow-x-auto px-4 py-3 no-scrollbar">
            <Pill active={catFilter === "All"} onClick={() => setCatFilter("All")}>
              All
            </Pill>
            {CATEGORIES.map((c) => (
              <Pill
                key={c.id}
                active={catFilter === c.id}
                onClick={() => setCatFilter(c.id)}
              >
                {c.name}
              </Pill>
            ))}
          </div>
          <div className="px-4 pb-2">
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span>Max price: π {maxPrice}</span>
              <span>{results.length} results</span>
            </div>
            <input
              type="range"
              min={5}
              max={200}
              step={5}
              value={maxPrice}
              onChange={(e) => setMaxPrice(Number(e.target.value))}
              className="mt-1 w-full accent-[var(--primary)]"
            />
          </div>
          <div className="p-4 pt-2">
            {results.length === 0 ? (
              <EmptyState
                icon="SearchX"
                title="No results"
                subtitle={`Nothing matched "${q}". Try another term.`}
              />
            ) : (
              <div className="grid grid-cols-2 gap-3">
                {results.map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
