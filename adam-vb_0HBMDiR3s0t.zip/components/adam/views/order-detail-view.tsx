"use client";

import { useAdam } from "@/contexts/adam-context";
import { fmtPi, fmtDate, type OrderStatus } from "@/lib/adam/types";
import { Icon, Button, Badge } from "../ui-bits";
import { cn } from "@/lib/utils";

const STEPS: { status: OrderStatus; label: string; icon: string }[] = [
  { status: "confirmed", label: "Confirmed", icon: "CircleCheck" },
  { status: "shipped", label: "Shipped", icon: "Truck" },
  { status: "delivered", label: "Delivered", icon: "PackageCheck" },
];

export function OrderDetailView({ orderId }: { orderId: string }) {
  const { state, setOrderStatus, navigate, showToast } = useAdam();
  const order = state.orders.find((o) => o.id === orderId);
  if (!order) return null;

  const stepIndex = STEPS.findIndex((s) => s.status === order.status);
  const isCancelled = order.status === "cancelled";
  const isReturned = order.status === "returned";

  return (
    <div className="space-y-5 p-4 pb-8">
      <div className="rounded-2xl border border-border bg-card p-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-xs text-muted-foreground">Tracking number</div>
            <div className="font-bold text-foreground">{order.trackingNumber}</div>
          </div>
          <div className="text-right">
            <div className="text-xs text-muted-foreground">Ordered</div>
            <div className="text-sm font-semibold text-foreground">
              {fmtDate(order.date)}
            </div>
          </div>
        </div>
      </div>

      {/* tracker */}
      {!isCancelled && !isReturned && (
        <div className="rounded-2xl border border-border bg-card p-4">
          <div className="flex items-center justify-between">
            {STEPS.map((s, i) => {
              const reached = i <= stepIndex;
              return (
                <div key={s.status} className="flex flex-1 flex-col items-center">
                  <div className="flex w-full items-center">
                    {i > 0 && (
                      <div
                        className={cn(
                          "h-1 flex-1",
                          i <= stepIndex ? "bg-primary" : "bg-muted"
                        )}
                      />
                    )}
                    <div
                      className={cn(
                        "grid h-10 w-10 shrink-0 place-items-center rounded-full",
                        reached
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted text-muted-foreground"
                      )}
                    >
                      <Icon name={s.icon} className="h-5 w-5" />
                    </div>
                    {i < STEPS.length - 1 && (
                      <div
                        className={cn(
                          "h-1 flex-1",
                          i < stepIndex ? "bg-primary" : "bg-muted"
                        )}
                      />
                    )}
                  </div>
                  <span
                    className={cn(
                      "mt-1.5 text-[11px] font-semibold",
                      reached ? "text-foreground" : "text-muted-foreground"
                    )}
                  >
                    {s.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {(isCancelled || isReturned) && (
        <div className="flex items-center gap-2 rounded-2xl border border-border bg-card p-4">
          <Badge tone={isCancelled ? "danger" : "muted"}>
            {isCancelled ? "Cancelled" : "Returned"}
          </Badge>
          <span className="text-sm text-muted-foreground">
            This order was {isCancelled ? "cancelled" : "returned"}.
          </span>
        </div>
      )}

      {/* items */}
      <div>
        <h2 className="mb-2 font-bold text-foreground">Items</h2>
        <div className="space-y-2">
          {order.lines.map((l) => (
            <button
              key={l.productId}
              onClick={() => navigate("product", l.productId)}
              className="flex w-full items-center gap-3 rounded-2xl border border-border bg-card p-3 text-left active-press"
            >
              <img
                src={l.image || "/placeholder.svg"}
                alt={l.name}
                className="h-14 w-14 rounded-xl bg-secondary object-cover"
              />
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-semibold text-foreground">
                  {l.name}
                </div>
                <div className="text-xs text-muted-foreground">Qty {l.qty}</div>
              </div>
              <span className="font-bold text-primary">{fmtPi(l.price * l.qty)}</span>
            </button>
          ))}
        </div>
      </div>

      {/* delivery */}
      <div>
        <h2 className="mb-2 font-bold text-foreground">Delivery address</h2>
        <div className="rounded-2xl border border-border bg-card p-3 text-sm text-muted-foreground">
          {order.address}
        </div>
      </div>

      {/* breakdown */}
      <div className="space-y-1 rounded-2xl border border-border bg-card p-4 text-sm">
        <Row label="Subtotal" value={fmtPi(order.subtotal)} />
        {order.discount > 0 && (
          <Row label="Points discount" value={`- ${fmtPi(order.discount)}`} />
        )}
        <Row label="Shipping" value={order.shipping === 0 ? "Free" : fmtPi(order.shipping)} />
        <Row label="Tax" value={fmtPi(order.tax)} />
        <div className="flex items-center justify-between border-t border-border pt-2 text-base font-extrabold text-foreground">
          <span>Total paid</span>
          <span className="text-primary">{fmtPi(order.total)}</span>
        </div>
        <div className="flex items-center justify-between pt-1 text-xs">
          <span className="text-muted-foreground">Points earned</span>
          <span className="font-bold text-accent-foreground">+{order.pointsEarned}</span>
        </div>
      </div>

      {/* actions */}
      <div className="space-y-2">
        {order.status === "confirmed" && (
          <Button
            variant="accent"
            className="w-full"
            onClick={() => {
              setOrderStatus(order.id, "shipped");
              showToast("Order marked as shipped", "success");
            }}
          >
            <Icon name="Truck" className="h-4 w-4" /> Simulate shipment
          </Button>
        )}
        {order.status === "shipped" && (
          <Button
            variant="primary"
            className="w-full"
            onClick={() => {
              setOrderStatus(order.id, "delivered");
              showToast("Order delivered", "success");
            }}
          >
            <Icon name="PackageCheck" className="h-4 w-4" /> Mark as delivered
          </Button>
        )}
        {(order.status === "confirmed" || order.status === "pending") && (
          <Button
            variant="outline"
            className="w-full"
            onClick={() => {
              setOrderStatus(order.id, "cancelled");
              showToast("Order cancelled");
            }}
          >
            Cancel order
          </Button>
        )}
        {order.status === "delivered" && (
          <Button
            variant="outline"
            className="w-full"
            onClick={() => {
              setOrderStatus(order.id, "returned");
              showToast("Return requested");
            }}
          >
            <Icon name="Undo2" className="h-4 w-4" /> Request return / refund
          </Button>
        )}
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-semibold text-foreground">{value}</span>
    </div>
  );
}
