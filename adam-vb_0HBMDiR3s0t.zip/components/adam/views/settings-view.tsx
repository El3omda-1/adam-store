"use client";

import { useTheme } from "next-themes";
import { useEffect, useState } from "react";
import { useAdam } from "@/contexts/adam-context";
import { Card, Icon, Button } from "@/components/adam/ui-bits";

function Toggle({
  on,
  onChange,
}: {
  on: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <button
      onClick={() => onChange(!on)}
      className={`relative h-6 w-11 rounded-full transition-colors active-press ${
        on ? "bg-primary" : "bg-muted"
      }`}
      aria-label="Toggle"
    >
      <span
        className={`absolute top-0.5 h-5 w-5 rounded-full bg-card shadow transition-transform ${
          on ? "translate-x-5" : "translate-x-0.5"
        }`}
      />
    </button>
  );
}

export function SettingsView() {
  const { state, setNotifications, resetData } = useAdam();
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  const [confirm, setConfirm] = useState(false);
  useEffect(() => setMounted(true), []);

  const themes: { id: string; label: string; icon: string }[] = [
    { id: "light", label: "Light", icon: "Sun" },
    { id: "dark", label: "Dark", icon: "Moon" },
    { id: "system", label: "System", icon: "Monitor" },
  ];

  return (
    <div className="px-4 py-4 space-y-4">
      <div>
        <h3 className="text-sm font-bold text-foreground mb-2">Appearance</h3>
        <Card className="p-2 flex gap-2">
          {themes.map((t) => {
            const active = mounted && theme === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setTheme(t.id)}
                className={`flex-1 flex flex-col items-center gap-1.5 py-3 rounded-xl active-press transition-colors ${
                  active
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-foreground"
                }`}
              >
                <Icon name={t.icon} className="h-5 w-5" />
                <span className="text-xs font-semibold">{t.label}</span>
              </button>
            );
          })}
        </Card>
      </div>

      <div>
        <h3 className="text-sm font-bold text-foreground mb-2">Preferences</h3>
        <Card className="divide-y divide-border">
          <div className="flex items-center justify-between px-4 py-3.5">
            <div className="flex items-center gap-3">
              <Icon name="Bell" className="h-4.5 w-4.5 text-primary" />
              <span className="text-sm font-medium text-foreground">
                Notifications
              </span>
            </div>
            <Toggle on={state.notifications} onChange={setNotifications} />
          </div>
          <div className="flex items-center justify-between px-4 py-3.5">
            <div className="flex items-center gap-3">
              <Icon name="Globe" className="h-4.5 w-4.5 text-primary" />
              <span className="text-sm font-medium text-foreground">Language</span>
            </div>
            <span className="text-sm text-muted-foreground">English</span>
          </div>
          <div className="flex items-center justify-between px-4 py-3.5">
            <div className="flex items-center gap-3">
              <Icon name="Coins" className="h-4.5 w-4.5 text-primary" />
              <span className="text-sm font-medium text-foreground">Currency</span>
            </div>
            <span className="text-sm text-muted-foreground">Pi (π)</span>
          </div>
        </Card>
      </div>

      <div>
        <h3 className="text-sm font-bold text-foreground mb-2">Data</h3>
        <Card className="p-4">
          {confirm ? (
            <div className="space-y-3">
              <p className="text-sm text-foreground">
                This clears your cart, orders, wishlist and points. Continue?
              </p>
              <div className="flex gap-2">
                <Button
                  variant="danger"
                  className="flex-1"
                  onClick={() => {
                    resetData();
                    setConfirm(false);
                  }}
                >
                  Yes, reset
                </Button>
                <Button variant="outline" onClick={() => setConfirm(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          ) : (
            <button
              onClick={() => setConfirm(true)}
              className="flex items-center gap-3 text-destructive font-medium text-sm active-press"
            >
              <Icon name="Trash2" className="h-4.5 w-4.5" />
              Reset all data
            </button>
          )}
        </Card>
      </div>

      <p className="text-center text-xs text-muted-foreground pt-2">
        Adam Marketplace · Powered by Pi Network
      </p>
    </div>
  );
}
