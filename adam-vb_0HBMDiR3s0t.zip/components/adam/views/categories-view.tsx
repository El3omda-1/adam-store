"use client";

import { useAdam } from "@/contexts/adam-context";
import { CATEGORIES, PRODUCTS } from "@/lib/adam/data";
import { Icon } from "../ui-bits";

export function CategoriesView() {
  const { navigate } = useAdam();
  return (
    <div className="p-4 space-y-3">
      {CATEGORIES.map((c) => {
        const count = PRODUCTS.filter((p) => p.category === c.id).length;
        return (
          <button
            key={c.id}
            onClick={() => navigate("category", c.id)}
            className="flex w-full items-center gap-3 rounded-2xl border border-border bg-card p-3.5 active-press"
          >
            <div
              className="grid h-12 w-12 shrink-0 place-items-center rounded-xl"
              style={{
                backgroundColor: `oklch(0.95 0.05 ${c.hue})`,
                color: `oklch(0.45 0.15 ${c.hue})`,
              }}
            >
              <Icon name={c.icon} className="h-6 w-6" />
            </div>
            <div className="flex-1 text-left">
              <div className="font-bold text-foreground">{c.name}</div>
              <div className="text-xs text-muted-foreground">
                {c.subcategories.join(" · ")}
              </div>
            </div>
            <span className="text-xs font-semibold text-muted-foreground">
              {count}
            </span>
            <Icon name="ChevronRight" className="h-5 w-5 text-muted-foreground" />
          </button>
        );
      })}
    </div>
  );
}
