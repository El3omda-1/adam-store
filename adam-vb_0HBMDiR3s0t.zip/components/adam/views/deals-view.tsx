"use client";

import { useEffect, useState } from "react";
import { PRODUCTS } from "@/lib/adam/data";
import { ProductCard } from "@/components/adam/product-card";
import { Icon } from "@/components/adam/ui-bits";

function useCountdown() {
  const [end] = useState(() => {
    const d = new Date();
    d.setHours(23, 59, 59, 999);
    return d.getTime();
  });
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);
  const diff = Math.max(0, end - now);
  const h = Math.floor(diff / 3600000);
  const m = Math.floor((diff % 3600000) / 60000);
  const s = Math.floor((diff % 60000) / 1000);
  return { h, m, s };
}

function pad(n: number) {
  return n.toString().padStart(2, "0");
}

export function DealsView() {
  const { h, m, s } = useCountdown();
  const deals = PRODUCTS.filter((p) => p.flashDeal);

  return (
    <div className="pb-6">
      <div className="bg-primary text-primary-foreground px-4 py-5">
        <div className="flex items-center gap-2">
          <Icon name="Zap" className="h-6 w-6 fill-current" />
          <h2 className="text-xl font-bold">Flash Deals</h2>
        </div>
        <p className="text-sm opacity-90 mt-1">Limited-time prices, while stocks last</p>
        <div className="flex items-center gap-2 mt-3">
          <span className="text-sm font-medium opacity-90">Ends in</span>
          {[pad(h), pad(m), pad(s)].map((v, i) => (
            <div key={i} className="flex items-center gap-2">
              <span className="bg-card text-foreground font-bold text-sm rounded-lg px-2 py-1 tabular-nums">
                {v}
              </span>
              {i < 2 && <span className="font-bold">:</span>}
            </div>
          ))}
        </div>
      </div>

      <div className="px-4 py-4">
        <div className="grid grid-cols-2 gap-3">
          {deals.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </div>
    </div>
  );
}
