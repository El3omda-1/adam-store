"use client";

import { useState } from "react";
import { useAdam } from "@/contexts/adam-context";
import {
  Button,
  Card,
  Icon,
  EmptyState,
  inputClass,
  labelClass,
} from "@/components/adam/ui-bits";

export function AddressesView() {
  const { state, addAddress, removeAddress } = useAdam();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    label: "",
    recipient: "",
    line: "",
    city: "",
    phone: "",
  });

  const valid = form.label && form.recipient && form.line && form.city && form.phone;

  return (
    <div className="px-4 py-4 space-y-3">
      {state.addresses.length === 0 && !open && (
        <EmptyState
          icon="MapPin"
          title="No addresses yet"
          subtitle="Add a shipping address to speed up checkout."
        />
      )}

      {state.addresses.map((a) => (
        <Card key={a.id} className="p-4">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-3">
              <div className="h-9 w-9 rounded-xl bg-secondary flex items-center justify-center shrink-0">
                <Icon name="MapPin" className="h-4.5 w-4.5 text-primary" />
              </div>
              <div>
                <p className="font-semibold text-foreground text-sm">{a.label}</p>
                <p className="text-sm text-foreground mt-0.5">{a.recipient}</p>
                <p className="text-sm text-muted-foreground">{a.line}</p>
                <p className="text-sm text-muted-foreground">
                  {a.city} · {a.phone}
                </p>
              </div>
            </div>
            <button
              onClick={() => removeAddress(a.id)}
              className="text-muted-foreground active-press p-1"
              aria-label="Remove address"
            >
              <Icon name="Trash2" className="h-4.5 w-4.5" />
            </button>
          </div>
        </Card>
      ))}

      {open ? (
        <Card className="p-4 space-y-3 ad-fade-up">
          {(
            [
              ["label", "Label (e.g. Home, Work)"],
              ["recipient", "Recipient name"],
              ["line", "Address line"],
              ["city", "City"],
              ["phone", "Phone number"],
            ] as const
          ).map(([key, label]) => (
            <div key={key}>
              <label className={labelClass}>{label}</label>
              <input
                className={inputClass}
                value={(form as any)[key]}
                onChange={(e) => setForm({ ...form, [key]: e.target.value })}
              />
            </div>
          ))}
          <div className="flex gap-2 pt-1">
            <Button
              className="flex-1"
              disabled={!valid}
              onClick={() => {
                addAddress(form);
                setForm({ label: "", recipient: "", line: "", city: "", phone: "" });
                setOpen(false);
              }}
            >
              Save address
            </Button>
            <Button variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
          </div>
        </Card>
      ) : (
        <Button variant="outline" className="w-full" onClick={() => setOpen(true)}>
          <Icon name="Plus" className="h-4 w-4" />
          Add new address
        </Button>
      )}
    </div>
  );
}
