"use client";

import { useAdam } from "@/contexts/adam-context";
import { LOYALTY_TIERS, tierFor, fmtPi, POINTS_TO_PI } from "@/lib/adam/types";
import { Icon, SectionTitle } from "../ui-bits";
import { cn } from "@/lib/utils";

export function ProfileView() {
  const { state } = useAdam();
  const { current, next } = tierFor(state.totalSpent);
  const progress = next
    ? Math.min(100, ((state.totalSpent - current.min) / (next.min - current.min)) * 100)
    : 100;

  return (
    <div className="space-y-5 p-4">
      {/* points card */}
      <div className="overflow-hidden rounded-3xl bg-gradient-to-br from-primary to-accent p-5 text-primary-foreground">
        <div className="flex items-center justify-between">
          <span className="inline-flex items-center gap-1 rounded-full bg-primary-foreground/20 px-2.5 py-1 text-xs font-bold">
            <Icon name="Crown" className="h-3.5 w-3.5" /> {current.name}
          </span>
          <Icon name="Award" className="h-6 w-6 opacity-80" />
        </div>
        <div className="mt-4 text-4xl font-extrabold">
          {state.loyaltyPoints.toLocaleString()}
        </div>
        <div className="text-sm opacity-90">
          loyalty points · worth {fmtPi(state.loyaltyPoints / POINTS_TO_PI)}
        </div>
      </div>

      {/* tier progress */}
      <div className="rounded-2xl border border-border bg-card p-4">
        <div className="flex items-center justify-between text-sm">
          <span className="font-bold text-foreground">{current.name}</span>
          {next ? (
            <span className="text-muted-foreground">{next.name}</span>
          ) : (
            <span className="text-primary font-bold">Top tier</span>
          )}
        </div>
        <div className="mt-2 h-2.5 overflow-hidden rounded-full bg-muted">
          <div
            className="h-full rounded-full bg-primary transition-all"
            style={{ width: `${progress}%` }}
          />
        </div>
        <p className="mt-2 text-xs text-muted-foreground">
          {next
            ? `Spend ${fmtPi(next.min - state.totalSpent)} more to reach ${next.name}.`
            : "You've unlocked the highest tier. Enjoy the perks!"}
        </p>
      </div>

      {/* how it works */}
      <div className="rounded-2xl border border-border bg-card p-4">
        <h3 className="mb-2 font-bold text-foreground">How points work</h3>
        <ul className="space-y-2 text-sm text-muted-foreground">
          <li className="flex items-start gap-2">
            <Icon name="Coins" className="mt-0.5 h-4 w-4 text-accent" />
            Earn 10 points for every 1 Pi spent.
          </li>
          <li className="flex items-start gap-2">
            <Icon name="Gift" className="mt-0.5 h-4 w-4 text-accent" />
            Redeem 100 points for 1 Pi off any order.
          </li>
          <li className="flex items-start gap-2">
            <Icon name="TrendingUp" className="mt-0.5 h-4 w-4 text-accent" />
            Higher tiers unlock bigger rewards.
          </li>
        </ul>
      </div>

      {/* tiers */}
      <div>
        <SectionTitle title="Membership tiers" />
        <div className="space-y-2">
          {LOYALTY_TIERS.map((t) => {
            const isCurrent = t.name === current.name;
            const unlocked = state.totalSpent >= t.min;
            return (
              <div
                key={t.name}
                className={cn(
                  "flex items-center gap-3 rounded-2xl border p-3.5",
                  isCurrent
                    ? "border-primary bg-primary/5"
                    : "border-border bg-card"
                )}
              >
                <div
                  className="grid h-10 w-10 place-items-center rounded-xl"
                  style={{
                    backgroundColor: `oklch(0.93 0.06 ${t.hue})`,
                    color: `oklch(0.45 0.16 ${t.hue})`,
                  }}
                >
                  <Icon name="Crown" className="h-5 w-5" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 text-sm font-bold text-foreground">
                    {t.name}
                    {isCurrent && (
                      <span className="rounded-full bg-primary px-2 py-0.5 text-[10px] text-primary-foreground">
                        Current
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-muted-foreground">{t.perk}</div>
                </div>
                <Icon
                  name={unlocked ? "CircleCheck" : "Lock"}
                  className={cn(
                    "h-5 w-5",
                    unlocked ? "text-positive" : "text-muted-foreground"
                  )}
                />
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
