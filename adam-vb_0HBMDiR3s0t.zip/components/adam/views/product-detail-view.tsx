"use client";

import { useState, useEffect } from "react";
import { useAdam } from "@/contexts/adam-context";
import { getProduct, getSeller, PRODUCTS } from "@/lib/adam/data";
import { fmtPi } from "@/lib/adam/types";
import { ProductCard } from "../product-card";
import {
  Icon,
  Button,
  Stars,
  Badge,
  SectionTitle,
  textareaClass,
} from "../ui-bits";
import { cn } from "@/lib/utils";

export function ProductDetailView({ productId }: { productId: string }) {
  const {
    navigate,
    setTab,
    addToCart,
    toggleWishlist,
    isWishlisted,
    toggleCompare,
    isCompared,
    recordView,
    reviewsFor,
    addReview,
    showToast,
  } = useAdam();

  const product = getProduct(productId);
  const [activeImg, setActiveImg] = useState(0);
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewText, setReviewText] = useState("");
  const [showReview, setShowReview] = useState(false);

  useEffect(() => {
    if (product) recordView(product.id);
    setActiveImg(0);
  }, [productId]);

  if (!product) return null;

  const seller = getSeller(product.sellerId);
  const reviews = reviewsFor(product.id);
  const wished = isWishlisted(product.id);
  const compared = isCompared(product.id);
  const discount = product.originalPrice
    ? Math.round(
        ((product.originalPrice - product.price) / product.originalPrice) * 100
      )
    : 0;
  const related = PRODUCTS.filter(
    (p) => p.category === product.category && p.id !== product.id
  ).slice(0, 6);

  const share = async () => {
    try {
      if (navigator.share) {
        await navigator.share({ title: product.name, text: product.name });
      } else {
        showToast("Link copied", "success");
      }
    } catch {
      /* cancelled */
    }
  };

  return (
    <div className="pb-28">
      {/* gallery */}
      <div className="relative bg-secondary">
        <div className="aspect-square overflow-hidden">
          <img
            src={product.images[activeImg] || product.image}
            alt={product.name}
            className="h-full w-full object-cover ad-fade-in"
          />
        </div>
        {discount > 0 && (
          <Badge tone="primary" className="absolute left-3 top-3">
            -{discount}% OFF
          </Badge>
        )}
        <div className="absolute right-3 top-3 flex flex-col gap-2">
          <button
            onClick={() => toggleWishlist(product.id)}
            aria-label="Wishlist"
            className="grid h-10 w-10 place-items-center rounded-full bg-card/90 backdrop-blur active-press"
          >
            <Icon
              name="Heart"
              className={cn(
                "h-5 w-5",
                wished ? "fill-primary text-primary" : "text-foreground"
              )}
            />
          </button>
          <button
            onClick={share}
            aria-label="Share"
            className="grid h-10 w-10 place-items-center rounded-full bg-card/90 backdrop-blur active-press"
          >
            <Icon name="Share2" className="h-5 w-5 text-foreground" />
          </button>
        </div>
        {/* thumbnails */}
        <div className="absolute bottom-3 left-0 right-0 flex justify-center gap-2">
          {product.images.map((img, i) => (
            <button
              key={i}
              onClick={() => setActiveImg(i)}
              className={cn(
                "h-2 rounded-full transition-all",
                i === activeImg ? "w-6 bg-primary" : "w-2 bg-card/70"
              )}
              aria-label={`Image ${i + 1}`}
            />
          ))}
        </div>
      </div>

      <div className="space-y-5 p-4">
        {/* title + price */}
        <div>
          <div className="flex items-center gap-2">
            <Badge tone="muted">{product.brand}</Badge>
            {product.stock < 20 && (
              <Badge tone="danger">Only {product.stock} left</Badge>
            )}
          </div>
          <h1 className="mt-2 text-xl font-extrabold text-foreground text-balance">
            {product.name}
          </h1>
          <div className="mt-2 flex items-center gap-2">
            <Stars rating={product.rating} size={16} />
            <span className="text-sm font-semibold text-foreground">
              {product.rating}
            </span>
            <span className="text-sm text-muted-foreground">
              ({product.reviewCount.toLocaleString()} reviews)
            </span>
          </div>
          <div className="mt-3 flex items-end gap-2">
            <span className="text-2xl font-extrabold text-primary">
              {fmtPi(product.price)}
            </span>
            {product.originalPrice && (
              <span className="pb-0.5 text-sm text-muted-foreground line-through">
                {fmtPi(product.originalPrice)}
              </span>
            )}
          </div>
        </div>

        {/* seller */}
        {seller && (
          <button
            onClick={() => navigate("seller", seller.id)}
            className="flex w-full items-center gap-3 rounded-2xl border border-border bg-card p-3 active-press"
          >
            <div className="grid h-10 w-10 place-items-center rounded-full bg-secondary">
              <Icon name="Store" className="h-5 w-5 text-foreground" />
            </div>
            <div className="flex-1 text-left">
              <div className="flex items-center gap-1 text-sm font-bold text-foreground">
                {seller.name}
                {seller.verified && (
                  <Icon name="BadgeCheck" className="h-4 w-4 text-primary" />
                )}
              </div>
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Stars rating={seller.rating} size={11} /> {seller.rating} ·{" "}
                {seller.reviewCount.toLocaleString()} ratings
              </div>
            </div>
            <Icon name="MessageCircle" className="h-5 w-5 text-primary" />
          </button>
        )}

        {/* description */}
        <div>
          <h2 className="mb-1.5 font-bold text-foreground">Description</h2>
          <p className="text-sm leading-relaxed text-muted-foreground">
            {product.description}
          </p>
        </div>

        {/* specs */}
        <div>
          <h2 className="mb-1.5 font-bold text-foreground">Specifications</h2>
          <div className="overflow-hidden rounded-2xl border border-border">
            {product.specs.map((s, i) => (
              <div
                key={s.label}
                className={cn(
                  "flex items-center justify-between px-3.5 py-2.5 text-sm",
                  i % 2 === 0 ? "bg-card" : "bg-secondary"
                )}
              >
                <span className="text-muted-foreground">{s.label}</span>
                <span className="font-semibold text-foreground">{s.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* compare button */}
        <Button
          variant={compared ? "primary" : "outline"}
          className="w-full"
          onClick={() => toggleCompare(product.id)}
        >
          <Icon name="GitCompare" className="h-4 w-4" />
          {compared ? "Added to comparison" : "Add to compare"}
        </Button>

        {/* reviews */}
        <div>
          <SectionTitle
            title={`Reviews (${reviews.length})`}
            action={showReview ? "Cancel" : "Write a review"}
            onAction={() => setShowReview((v) => !v)}
          />
          {showReview && (
            <div className="mb-3 rounded-2xl border border-border bg-card p-3 ad-fade-up">
              <div className="mb-2 flex items-center gap-1">
                {[1, 2, 3, 4, 5].map((i) => (
                  <button
                    key={i}
                    onClick={() => setReviewRating(i)}
                    aria-label={`Rate ${i}`}
                  >
                    <Icon
                      name="Star"
                      className={cn(
                        "h-6 w-6",
                        i <= reviewRating
                          ? "fill-accent text-accent"
                          : "fill-muted text-muted"
                      )}
                    />
                  </button>
                ))}
              </div>
              <textarea
                value={reviewText}
                onChange={(e) => setReviewText(e.target.value)}
                placeholder="Share your experience…"
                rows={3}
                className={textareaClass}
              />
              <div className="mt-2 flex items-center gap-2">
                <Button variant="outline" size="sm">
                  <Icon name="Camera" className="h-4 w-4" /> Add photo
                </Button>
                <Button
                  size="sm"
                  className="ml-auto"
                  disabled={!reviewText.trim()}
                  onClick={() => {
                    addReview(product.id, reviewRating, reviewText.trim());
                    setReviewText("");
                    setShowReview(false);
                  }}
                >
                  Post review
                </Button>
              </div>
            </div>
          )}
          <div className="space-y-3">
            {reviews.length === 0 && (
              <p className="text-sm text-muted-foreground">
                No reviews yet. Be the first!
              </p>
            )}
            {reviews.map((r) => (
              <div
                key={r.id}
                className="rounded-2xl border border-border bg-card p-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="grid h-8 w-8 place-items-center rounded-full bg-secondary text-xs font-bold text-foreground">
                      {r.user.charAt(0)}
                    </div>
                    <span className="text-sm font-semibold text-foreground">
                      {r.user}
                    </span>
                  </div>
                  <span className="text-xs text-muted-foreground">{r.date}</span>
                </div>
                <Stars rating={r.rating} size={12} className="mt-2" />
                <p className="mt-1.5 text-sm text-muted-foreground">
                  {r.comment}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* related */}
        {related.length > 0 && (
          <div>
            <SectionTitle title="You may also like" />
            <div className="grid grid-cols-2 gap-3">
              {related.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </div>
        )}
      </div>

      {/* sticky action bar */}
      <div className="fixed inset-x-0 bottom-0 z-40 mx-auto flex max-w-md items-center gap-2 border-t border-border bg-card/95 p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] backdrop-blur">
        <Button
          variant="outline"
          className="flex-1"
          onClick={() => addToCart(product.id)}
        >
          <Icon name="ShoppingCart" className="h-4 w-4" /> Add to cart
        </Button>
        <Button
          className="flex-1"
          onClick={() => {
            addToCart(product.id);
            navigate("checkout");
          }}
        >
          <Icon name="Zap" className="h-4 w-4" /> Buy now
        </Button>
      </div>
    </div>
  );
}
