'use client';

import { AdamMarketplace } from '@/components/adam/adam-app';

export default function HomePage() {
  return <AdamMarketplace />;
}
