"use client";

import {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  useRef,
  type ReactNode,
} from "react";
import { usePurchase } from "@/lib/pi-payment";
import { PRODUCTS, getProduct, getSeller, SEED_REVIEWS } from "@/lib/adam/data";
import {
  type AdamState,
  type Order,
  type OrderStatus,
  type Review,
  type Address,
  type CartItem,
  CHECKOUT_PRODUCT_SLUG,
  POINTS_PER_PI,
  POINTS_TO_PI,
  uid,
} from "@/lib/adam/types";

const STORAGE_KEY = "adam-marketplace-v1";

export type Tab = "home" | "categories" | "cart" | "wishlist" | "account";

export interface Screen {
  name:
    | "tab"
    | "product"
    | "category"
    | "search"
    | "checkout"
    | "orders"
    | "order-detail"
    | "profile"
    | "compare"
    | "seller"
    | "deals"
    | "addresses"
    | "settings";
  param?: string;
}

interface Toast {
  id: string;
  message: string;
  tone: "default" | "success" | "error";
}

function defaultState(): AdamState {
  return {
    cart: [],
    savedForLater: [],
    wishlist: [],
    compare: [],
    recentlyViewed: [],
    orders: [],
    reviews: SEED_REVIEWS,
    loyaltyPoints: 120,
    totalSpent: 0,
    addresses: [
      {
        id: "addr1",
        label: "Home",
        recipient: "Pi Pioneer",
        line: "123 Pi Avenue, Block C",
        city: "Nairobi",
        phone: "+254 700 000 000",
      },
    ],
    notifications: true,
  };
}

interface AdamContextType {
  ready: boolean;
  state: AdamState;
  // nav
  tab: Tab;
  setTab: (t: Tab) => void;
  screen: Screen;
  navigate: (name: Screen["name"], param?: string) => void;
  back: () => void;
  // cart
  cartCount: number;
  cartSubtotal: number;
  addToCart: (productId: string, qty?: number) => void;
  setQty: (productId: string, qty: number) => void;
  removeFromCart: (productId: string) => void;
  saveForLater: (productId: string) => void;
  moveToCart: (productId: string) => void;
  clearCart: () => void;
  // wishlist / compare
  toggleWishlist: (productId: string) => void;
  isWishlisted: (productId: string) => boolean;
  toggleCompare: (productId: string) => void;
  isCompared: (productId: string) => boolean;
  // recently viewed
  recordView: (productId: string) => void;
  // reviews
  reviewsFor: (productId: string) => Review[];
  addReview: (productId: string, rating: number, comment: string) => void;
  // orders / checkout
  placeOrder: (params: {
    address: string;
    pointsToRedeem: number;
  }) => Promise<{ ok: boolean; order?: Order; reason?: string }>;
  setOrderStatus: (orderId: string, status: OrderStatus) => void;
  // addresses
  addAddress: (a: Omit<Address, "id">) => void;
  removeAddress: (id: string) => void;
  // settings
  setNotifications: (v: boolean) => void;
  resetData: () => void;
  // toasts
  toasts: Toast[];
  showToast: (message: string, tone?: Toast["tone"]) => void;
}

const AdamContext = createContext<AdamContextType | undefined>(undefined);

const SHIPPING_FLAT = 1.5;
const TAX_RATE = 0.05;

export function AdamProvider({ children }: { children: ReactNode }) {
  const { makePurchase } = usePurchase();
  const [ready, setReady] = useState(false);
  const [state, setState] = useState<AdamState>(defaultState);
  const [tab, setTabState] = useState<Tab>("home");
  const [history, setHistory] = useState<Screen[]>([{ name: "tab" }]);
  const [toasts, setToasts] = useState<Toast[]>([]);

  // hydrate
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        setState({ ...defaultState(), ...parsed });
      }
    } catch {
      /* ignore */
    }
    setReady(true);
  }, []);

  // persist
  useEffect(() => {
    if (!ready) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      /* ignore */
    }
  }, [state, ready]);

  const screen = history[history.length - 1];

  const navigate = useCallback((name: Screen["name"], param?: string) => {
    setHistory((h) => [...h, { name, param }]);
    if (typeof window !== "undefined") window.scrollTo({ top: 0 });
  }, []);

  const back = useCallback(() => {
    setHistory((h) => (h.length > 1 ? h.slice(0, -1) : h));
  }, []);

  const setTab = useCallback((t: Tab) => {
    setTabState(t);
    setHistory([{ name: "tab" }]);
    if (typeof window !== "undefined") window.scrollTo({ top: 0 });
  }, []);

  const toastTimers = useRef<Record<string, ReturnType<typeof setTimeout>>>({});
  const showToast = useCallback(
    (message: string, tone: Toast["tone"] = "default") => {
      const id = uid("t");
      setToasts((t) => [...t, { id, message, tone }]);
      toastTimers.current[id] = setTimeout(() => {
        setToasts((t) => t.filter((x) => x.id !== id));
      }, 2600);
    },
    []
  );

  // ---- cart ----
  const addToCart = useCallback(
    (productId: string, qty = 1) => {
      setState((s) => {
        const existing = s.cart.find((c) => c.productId === productId);
        const cart = existing
          ? s.cart.map((c) =>
              c.productId === productId ? { ...c, qty: c.qty + qty } : c
            )
          : [...s.cart, { productId, qty }];
        return { ...s, cart };
      });
      showToast("Added to cart", "success");
    },
    [showToast]
  );

  const setQty = useCallback((productId: string, qty: number) => {
    setState((s) => ({
      ...s,
      cart:
        qty <= 0
          ? s.cart.filter((c) => c.productId !== productId)
          : s.cart.map((c) =>
              c.productId === productId ? { ...c, qty } : c
            ),
    }));
  }, []);

  const removeFromCart = useCallback((productId: string) => {
    setState((s) => ({
      ...s,
      cart: s.cart.filter((c) => c.productId !== productId),
    }));
  }, []);

  const saveForLater = useCallback((productId: string) => {
    setState((s) => ({
      ...s,
      cart: s.cart.filter((c) => c.productId !== productId),
      savedForLater: s.savedForLater.includes(productId)
        ? s.savedForLater
        : [...s.savedForLater, productId],
    }));
  }, []);

  const moveToCart = useCallback((productId: string) => {
    setState((s) => {
      const existing = s.cart.find((c) => c.productId === productId);
      const cart = existing
        ? s.cart.map((c) =>
            c.productId === productId ? { ...c, qty: c.qty + 1 } : c
          )
        : [...s.cart, { productId, qty: 1 }];
      return {
        ...s,
        cart,
        savedForLater: s.savedForLater.filter((id) => id !== productId),
      };
    });
  }, []);

  const clearCart = useCallback(() => {
    setState((s) => ({ ...s, cart: [] }));
  }, []);

  // ---- wishlist / compare ----
  const toggleWishlist = useCallback(
    (productId: string) => {
      setState((s) => {
        const has = s.wishlist.includes(productId);
        showToast(has ? "Removed from wishlist" : "Saved to wishlist");
        return {
          ...s,
          wishlist: has
            ? s.wishlist.filter((id) => id !== productId)
            : [...s.wishlist, productId],
        };
      });
    },
    [showToast]
  );

  const isWishlisted = useCallback(
    (productId: string) => state.wishlist.includes(productId),
    [state.wishlist]
  );

  const toggleCompare = useCallback(
    (productId: string) => {
      setState((s) => {
        const has = s.compare.includes(productId);
        if (!has && s.compare.length >= 4) {
          showToast("You can compare up to 4 products", "error");
          return s;
        }
        showToast(has ? "Removed from compare" : "Added to compare");
        return {
          ...s,
          compare: has
            ? s.compare.filter((id) => id !== productId)
            : [...s.compare, productId],
        };
      });
    },
    [showToast]
  );

  const isCompared = useCallback(
    (productId: string) => state.compare.includes(productId),
    [state.compare]
  );

  // ---- recently viewed ----
  const recordView = useCallback((productId: string) => {
    setState((s) => ({
      ...s,
      recentlyViewed: [
        productId,
        ...s.recentlyViewed.filter((id) => id !== productId),
      ].slice(0, 12),
    }));
  }, []);

  // ---- reviews ----
  const reviewsFor = useCallback(
    (productId: string) => state.reviews.filter((r) => r.productId === productId),
    [state.reviews]
  );

  const addReview = useCallback(
    (productId: string, rating: number, comment: string) => {
      const review: Review = {
        id: uid("r"),
        productId,
        user: "You",
        rating,
        comment,
        date: "just now",
      };
      setState((s) => ({ ...s, reviews: [review, ...s.reviews] }));
      showToast("Review posted", "success");
    },
    [showToast]
  );

  // ---- checkout ----
  const placeOrder = useCallback(
    async ({
      address,
      pointsToRedeem,
    }: {
      address: string;
      pointsToRedeem: number;
    }): Promise<{ ok: boolean; order?: Order; reason?: string }> => {
      const lines = state.cart
        .map((c) => {
          const p = getProduct(c.productId);
          if (!p) return null;
          return {
            productId: p.id,
            name: p.name,
            image: p.image,
            price: p.price,
            qty: c.qty,
          };
        })
        .filter(Boolean) as Order["lines"];

      if (lines.length === 0) return { ok: false, reason: "empty" };

      const subtotal = lines.reduce((sum, l) => sum + l.price * l.qty, 0);
      const shipping = subtotal > 50 ? 0 : SHIPPING_FLAT;
      const redeemable = Math.min(
        pointsToRedeem,
        state.loyaltyPoints,
        Math.floor(subtotal * POINTS_TO_PI)
      );
      const discount = redeemable / POINTS_TO_PI;
      const taxable = Math.max(0, subtotal - discount);
      const tax = +(taxable * TAX_RATE).toFixed(2);
      const total = +(taxable + shipping + tax).toFixed(2);

      let paymentId: string | undefined;
      try {
        const result = await makePurchase(CHECKOUT_PRODUCT_SLUG);
        paymentId = result?.paymentId || result?.txid;
      } catch (e: any) {
        const code = e?.code || e?.message || "";
        if (typeof code === "string" && code.includes("cancel")) {
          return { ok: false, reason: "cancelled" };
        }
        // sandbox / product_not_found: proceed anyway so the demo flow works
      }

      const pointsEarned = Math.floor(total * POINTS_PER_PI);
      const order: Order = {
        id: uid("ord"),
        trackingNumber: `AD${Date.now().toString().slice(-9)}`,
        lines,
        subtotal,
        shipping,
        tax,
        discount,
        total,
        status: "confirmed",
        date: Date.now(),
        pointsEarned,
        paymentId,
        address,
      };

      setState((s) => ({
        ...s,
        orders: [order, ...s.orders],
        cart: [],
        loyaltyPoints: s.loyaltyPoints - redeemable + pointsEarned,
        totalSpent: +(s.totalSpent + total).toFixed(2),
      }));

      return { ok: true, order };
    },
    [state.cart, state.loyaltyPoints, makePurchase]
  );

  const setOrderStatus = useCallback((orderId: string, status: OrderStatus) => {
    setState((s) => ({
      ...s,
      orders: s.orders.map((o) => (o.id === orderId ? { ...o, status } : o)),
    }));
  }, []);

  // ---- addresses ----
  const addAddress = useCallback(
    (a: Omit<Address, "id">) => {
      setState((s) => ({
        ...s,
        addresses: [...s.addresses, { ...a, id: uid("addr") }],
      }));
      showToast("Address added", "success");
    },
    [showToast]
  );

  const removeAddress = useCallback((id: string) => {
    setState((s) => ({
      ...s,
      addresses: s.addresses.filter((a) => a.id !== id),
    }));
  }, []);

  const setNotifications = useCallback((v: boolean) => {
    setState((s) => ({ ...s, notifications: v }));
  }, []);

  const resetData = useCallback(() => {
    setState(defaultState());
    showToast("Data reset", "success");
  }, [showToast]);

  const cartCount = state.cart.reduce((sum, c) => sum + c.qty, 0);
  const cartSubtotal = state.cart.reduce((sum, c) => {
    const p = getProduct(c.productId);
    return sum + (p ? p.price * c.qty : 0);
  }, 0);

  const value: AdamContextType = {
    ready,
    state,
    tab,
    setTab,
    screen,
    navigate,
    back,
    cartCount,
    cartSubtotal,
    addToCart,
    setQty,
    removeFromCart,
    saveForLater,
    moveToCart,
    clearCart,
    toggleWishlist,
    isWishlisted,
    toggleCompare,
    isCompared,
    recordView,
    reviewsFor,
    addReview,
    placeOrder,
    setOrderStatus,
    addAddress,
    removeAddress,
    setNotifications,
    resetData,
    toasts,
    showToast,
  };

  return <AdamContext.Provider value={value}>{children}</AdamContext.Provider>;
}

export function useAdam() {
  const ctx = useContext(AdamContext);
  if (!ctx) throw new Error("useAdam must be used within AdamProvider");
  return ctx;
}

export { PRODUCTS, getProduct, getSeller };
